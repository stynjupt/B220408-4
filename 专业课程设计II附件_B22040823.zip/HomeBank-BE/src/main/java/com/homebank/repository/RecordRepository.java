package com.homebank.repository;

import com.homebank.model.Record;
import com.homebank.model.enums.RecordType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RecordRepository
    extends JpaRepository<Record, Long>, JpaSpecificationExecutor<Record> {

  Page<Record> findByUserId(Long userId, Pageable pageable);

  Page<Record> findByFamilyId(Long familyId, Pageable pageable);

  @Query(
      "SELECT r FROM Record r WHERE r.family.id = :familyId AND r.account.id IN :accountIds "
          + "ORDER BY r.date DESC")
  Page<Record> findByFamilyIdAndAccountIdIn(
      @Param("familyId") Long familyId,
      @Param("accountIds") List<Long> accountIds,
      Pageable pageable);

  List<Record> findByAccountId(Long accountId);

  @Query(
      "SELECT COALESCE(SUM(r.amount), 0) FROM Record r "
          + "WHERE r.family.id = :familyId "
          + "AND r.type = :type "
          + "AND r.date >= :startDate "
          + "AND r.date < :endDate")
  BigDecimal sumByFamilyIdAndTypeAndDateBetween(
      @Param("familyId") Long familyId,
      @Param("type") RecordType type,
      @Param("startDate") LocalDateTime startDate,
      @Param("endDate") LocalDateTime endDate);

  @Query(
      "SELECT COALESCE(SUM(ABS(r.amount)), 0) FROM Record r "
          + "WHERE r.category.id = :categoryId "
          + "AND r.type = :type "
          + "AND r.date >= :startDate "
          + "AND r.date < :endDate")
  BigDecimal sumByCategoryIdAndTypeAndDateBetween(
      @Param("categoryId") Long categoryId,
      @Param("type") RecordType type,
      @Param("startDate") LocalDateTime startDate,
      @Param("endDate") LocalDateTime endDate);

  @Query(
      "SELECT COALESCE(SUM(r.amount), 0) FROM Record r "
          + "WHERE r.family.id = :familyId "
          + "AND r.account.includeInStatistics = true "
          + "AND r.type = 'INCOME' "
          + "AND (:scopeUserId IS NULL OR r.user.id = :scopeUserId) "
          + "AND (:dateGe IS NULL OR r.date >= :dateGe) "
          + "AND (:dateLt IS NULL OR r.date < :dateLt)")
  BigDecimal getTotalIncomes(
      @Param("familyId") Long familyId,
      @Param("scopeUserId") Long scopeUserId,
      @Param("dateGe") LocalDateTime dateGe,
      @Param("dateLt") LocalDateTime dateLt);

  @Query(
      "SELECT COALESCE(SUM(r.amount), 0) FROM Record r "
          + "WHERE r.family.id = :familyId "
          + "AND r.account.includeInStatistics = true "
          + "AND r.type = 'EXPENSE' "
          + "AND (:scopeUserId IS NULL OR r.user.id = :scopeUserId) "
          + "AND (:dateGe IS NULL OR r.date >= :dateGe) "
          + "AND (:dateLt IS NULL OR r.date < :dateLt)")
  BigDecimal getTotalExpenses(
      @Param("familyId") Long familyId,
      @Param("scopeUserId") Long scopeUserId,
      @Param("dateGe") LocalDateTime dateGe,
      @Param("dateLt") LocalDateTime dateLt);

  @Query(
      "SELECT CASE WHEN r.type = 'INCOME' THEN r.amount ELSE -r.amount END AS y, r.date AS x "
          + "FROM Record r "
          + "WHERE r.family.id = :familyId "
          + "AND r.account.includeInStatistics = true "
          + "AND (:scopeUserId IS NULL OR r.user.id = :scopeUserId) "
          + "AND (:dateGe IS NULL OR r.date >= :dateGe) "
          + "AND (:dateLt IS NULL OR r.date < :dateLt) "
          + "ORDER BY r.date ASC")
  List<Object[]> getSpendingEvolution(
      @Param("familyId") Long familyId,
      @Param("scopeUserId") Long scopeUserId,
      @Param("dateGe") LocalDateTime dateGe,
      @Param("dateLt") LocalDateTime dateLt);
}

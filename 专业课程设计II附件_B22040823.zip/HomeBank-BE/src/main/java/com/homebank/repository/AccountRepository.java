package com.homebank.repository;

import com.homebank.model.Account;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

  List<Account> findByFamilyId(Long familyId);

  @Query("SELECT a FROM Account a LEFT JOIN FETCH a.permissions WHERE a.family.id = :familyId")
  List<Account> findByFamilyIdWithPermissions(@Param("familyId") Long familyId);

  @Query(
      "SELECT COALESCE(SUM(a.balance), 0) FROM Account a "
          + "WHERE a.family.id = :familyId "
          + "AND a.includeInStatistics = true")
  BigDecimal getTotalBalanceByFamily(@Param("familyId") Long familyId);

  @Query("SELECT a FROM Account a WHERE a.id IN :accountIds")
  List<Account> findAllByIdIn(@Param("accountIds") List<Long> accountIds);
}

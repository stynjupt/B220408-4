package com.homebank.repository;

import com.homebank.model.Alert;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AlertRepository extends JpaRepository<Alert, Long> {

  List<Alert> findByUserId(Long userId);

  List<Alert> findByUserIdAndIsRead(Long userId, Boolean isRead);

  Long countByUserIdAndIsRead(Long userId, Boolean isRead);

  List<Alert> findByBudgetId(Long budgetId);
}

package com.homebank.repository;

import com.homebank.model.AccountPermission;
import com.homebank.model.enums.AccountPermissionType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountPermissionRepository extends JpaRepository<AccountPermission, Long> {

  Optional<AccountPermission> findByAccountIdAndUserId(Long accountId, Long userId);

  List<AccountPermission> findByUserId(Long userId);

  @Query(
      "SELECT ap FROM AccountPermission ap LEFT JOIN FETCH ap.account WHERE ap.user.id = :userId")
  List<AccountPermission> findByUserIdWithAccount(@Param("userId") Long userId);

  List<AccountPermission> findByAccountId(Long accountId);

  @Query(
      "SELECT ap FROM AccountPermission ap LEFT JOIN FETCH ap.user WHERE ap.account.id ="
          + " :accountId")
  List<AccountPermission> findByAccountIdWithUser(@Param("accountId") Long accountId);

  @Query(
      "SELECT ap FROM AccountPermission ap WHERE ap.user.id = :userId AND ap.permission ="
          + " :permission")
  List<AccountPermission> findByUserIdAndPermission(
      @Param("userId") Long userId, @Param("permission") AccountPermissionType permission);

  @Query(
      "SELECT ap.account.id FROM AccountPermission ap WHERE ap.user.id = :userId AND ap.permission"
          + " = 'EDIT'")
  List<Long> findEditableAccountIdsByUserId(@Param("userId") Long userId);

  @Query("SELECT ap.account.id FROM AccountPermission ap WHERE ap.user.id = :userId")
  List<Long> findVisibleAccountIdsByUserId(@Param("userId") Long userId);

  @Query(
      "SELECT COUNT(ap) > 0 FROM AccountPermission ap WHERE ap.user.id = :userId AND ap.account.id"
          + " = :accountId")
  boolean hasPermission(@Param("userId") Long userId, @Param("accountId") Long accountId);

  @Query(
      "SELECT COUNT(ap) > 0 FROM AccountPermission ap WHERE ap.user.id = :userId AND ap.account.id"
          + " = :accountId AND ap.permission = 'EDIT'")
  boolean hasEditPermission(@Param("userId") Long userId, @Param("accountId") Long accountId);

  @Query(
      "SELECT ap.permission FROM AccountPermission ap WHERE ap.user.id = :userId AND ap.account.id"
          + " = :accountId")
  Optional<AccountPermissionType> getPermissionType(
      @Param("userId") Long userId, @Param("accountId") Long accountId);

  void deleteByAccountIdAndUserId(Long accountId, Long userId);

  void deleteByAccountId(Long accountId);

  long countByAccountId(Long accountId);

  @Query(
      "SELECT ap FROM AccountPermission ap WHERE ap.user.id = :userId AND ap.account.family.id ="
          + " :familyId")
  List<AccountPermission> findByUserIdAndFamilyId(
      @Param("userId") Long userId, @Param("familyId") Long familyId);
}

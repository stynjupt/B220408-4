package com.homebank.repository;

import com.homebank.model.Category;
import com.homebank.model.enums.RecordType;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

  List<Category> findByFamilyId(Long familyId);

  List<Category> findByFamilyIdAndType(Long familyId, RecordType type);

  @Query(
      "SELECT c, SUM(r.amount), COUNT(r) "
          + "FROM Record r JOIN r.category c "
          + "WHERE r.family.id = :familyId "
          + "AND r.account.includeInStatistics = true "
          + "AND r.type = 'EXPENSE' "
          + "AND (:scopeUserId IS NULL OR r.user.id = :scopeUserId) "
          + "AND (:dateGe IS NULL OR r.date >= :dateGe) "
          + "AND (:dateLt IS NULL OR r.date < :dateLt) "
          + "GROUP BY c.id")
  List<Object[]> findCategoriesAnalytic(
      @Param("familyId") Long familyId,
      @Param("scopeUserId") Long scopeUserId,
      @Param("dateGe") LocalDateTime dateGe,
      @Param("dateLt") LocalDateTime dateLt);
}

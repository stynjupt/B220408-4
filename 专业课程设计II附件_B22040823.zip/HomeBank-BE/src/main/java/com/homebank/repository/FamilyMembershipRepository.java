package com.homebank.repository;

import com.homebank.model.FamilyMembership;
import com.homebank.model.enums.UserRole;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FamilyMembershipRepository extends JpaRepository<FamilyMembership, Long> {

  Optional<FamilyMembership> findByUserIdAndFamilyId(Long userId, Long familyId);

  @Query(
      "SELECT fm FROM FamilyMembership fm WHERE fm.user.id = :userId AND fm.family.id = :familyId"
          + " AND fm.isActive = true")
  Optional<FamilyMembership> findActiveByUserIdAndFamilyId(
      @Param("userId") Long userId, @Param("familyId") Long familyId);

  List<FamilyMembership> findByUserId(Long userId);

  @Query("SELECT fm FROM FamilyMembership fm WHERE fm.user.id = :userId AND fm.isActive = true")
  List<FamilyMembership> findActiveByUserId(@Param("userId") Long userId);

  List<FamilyMembership> findByFamilyId(Long familyId);

  @Query(
      "SELECT fm FROM FamilyMembership fm LEFT JOIN FETCH fm.user WHERE fm.family.id = :familyId"
          + " AND fm.isActive = true")
  List<FamilyMembership> findActiveByFamilyIdWithUser(@Param("familyId") Long familyId);

  @Query(
      "SELECT fm FROM FamilyMembership fm WHERE fm.family.id = :familyId AND fm.role = :role AND"
          + " fm.isActive = true")
  List<FamilyMembership> findByFamilyIdAndRole(
      @Param("familyId") Long familyId, @Param("role") UserRole role);

  @Query(
      "SELECT COUNT(fm) > 0 FROM FamilyMembership fm WHERE fm.user.id = :userId AND fm.family.id ="
          + " :familyId AND fm.isActive = true")
  boolean existsActiveByUserIdAndFamilyId(
      @Param("userId") Long userId, @Param("familyId") Long familyId);

  @Query(
      "SELECT COUNT(fm) > 0 FROM FamilyMembership fm WHERE fm.user.id = :userId AND fm.family.id ="
          + " :familyId AND fm.role = 'FAMILY_ADMIN' AND fm.isActive = true")
  boolean isUserAdminInFamily(@Param("userId") Long userId, @Param("familyId") Long familyId);

  @Query(
      "SELECT COUNT(fm) FROM FamilyMembership fm WHERE fm.family.id = :familyId AND fm.isActive ="
          + " true")
  long countActiveByFamilyId(@Param("familyId") Long familyId);

  @Query(
      "SELECT COUNT(fm) FROM FamilyMembership fm WHERE fm.family.id = :familyId AND fm.role ="
          + " 'FAMILY_ADMIN' AND fm.isActive = true")
  long countAdminsByFamilyId(@Param("familyId") Long familyId);

  void deleteByUserIdAndFamilyId(Long userId, Long familyId);
}

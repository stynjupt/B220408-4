package com.homebank.model;

import com.homebank.model.enums.AccountPermissionType;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "accounts")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Account {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "family_id", nullable = false)
  private Family family;

  @Column(nullable = false, length = 100)
  private String name;

  @Column(nullable = false, precision = 15, scale = 2)
  @Builder.Default
  private BigDecimal balance = BigDecimal.ZERO;

  @Column(nullable = false, length = 3)
  private String currency;

  @Column(length = 20)
  private String color;

  @Column(length = 50)
  private String icon;

  @Column(name = "include_in_statistics", nullable = false)
  @Builder.Default
  private Boolean includeInStatistics = true;

  @CreationTimestamp
  @Column(name = "created_at", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @UpdateTimestamp
  @Column(name = "updated_at")
  private LocalDateTime updatedAt;

  @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<AccountPermission> permissions = new ArrayList<>();

  @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<Record> records = new ArrayList<>();

  public void updateBalance(BigDecimal amount) {
    this.balance = this.balance.add(amount);
  }

  public boolean hasUserPermission(Long userId) {
    return permissions.stream()
        .anyMatch(p -> p.getUser().getId().equals(userId));
  }

  public boolean hasUserEditPermission(Long userId) {
    return permissions.stream()
        .anyMatch(
            p ->
                p.getUser().getId().equals(userId)
                    && AccountPermissionType.EDIT.equals(p.getPermission()));
  }

  public AccountPermissionType getUserPermissionType(Long userId) {
    return permissions.stream()
        .filter(p -> p.getUser().getId().equals(userId))
        .map(AccountPermission::getPermission)
        .findFirst()
        .orElse(null);
  }

  public List<Long> getAuthorizedUserIds() {
    return permissions.stream().map(p -> p.getUser().getId()).toList();
  }
}

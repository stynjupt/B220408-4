package com.homebank.model.enums;

public enum InvitationStatus {
  PENDING,    
  ACCEPTED,   
  REJECTED,   
  EXPIRED     
}

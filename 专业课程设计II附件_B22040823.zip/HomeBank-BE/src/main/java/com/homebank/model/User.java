package com.homebank.model;

import com.homebank.model.enums.UserRole;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
@Table(name = "users")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@com.fasterxml.jackson.annotation.JsonIgnoreProperties(
    value = {"authorities", "enabled", "accountNonExpired", "credentialsNonExpired", "accountNonLocked", "username"},
    ignoreUnknown = true
)
public class User implements UserDetails {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(unique = true, nullable = false)
  private String email;

  @Column(name = "password_hash", nullable = false)
  private String password;

  @Column(name = "first_name", nullable = false, length = 50)
  private String firstName;

  @Column(name = "last_name", nullable = false, length = 50)
  private String lastName;

  @Column(name = "is_active", nullable = false)
  @Builder.Default
  private Boolean isActive = true;

  @CreationTimestamp
  @Column(name = "created_at", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @UpdateTimestamp
  @Column(name = "updated_at")
  private LocalDateTime updatedAt;

  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  @com.fasterxml.jackson.annotation.JsonIgnore
  private List<FamilyMembership> memberships = new ArrayList<>();

  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  @com.fasterxml.jackson.annotation.JsonIgnore
  private List<AccountPermission> accountPermissions = new ArrayList<>();

  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  @com.fasterxml.jackson.annotation.JsonIgnore
  private List<Record> records = new ArrayList<>();

  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  @com.fasterxml.jackson.annotation.JsonIgnore
  private List<Alert> alerts = new ArrayList<>();

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    
    return memberships.stream()
        .filter(FamilyMembership::isActiveMember)
        .map(m -> new SimpleGrantedAuthority("ROLE_" + m.getRole().name()))
        .collect(Collectors.toList());
  }

  @Override
  public String getPassword() {
    return password;
  }

  @Override
  public String getUsername() {
    return email;
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return isActive;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return isActive;
  }

  public FamilyMembership getMembershipInFamily(Long familyId) {
    return memberships.stream()
        .filter(m -> m.getFamily().getId().equals(familyId))
        .filter(FamilyMembership::isActiveMember)
        .findFirst()
        .orElse(null);
  }

  public boolean isAdminInFamily(Long familyId) {
    FamilyMembership membership = getMembershipInFamily(familyId);
    return membership != null && membership.isAdmin();
  }

  public boolean isMemberOfFamily(Long familyId) {
    return getMembershipInFamily(familyId) != null;
  }

  public UserRole getRoleInFamily(Long familyId) {
    FamilyMembership membership = getMembershipInFamily(familyId);
    return membership != null ? membership.getRole() : null;
  }

  public List<Family> getActiveFamilies() {
    return memberships.stream()
        .filter(FamilyMembership::isActiveMember)
        .map(FamilyMembership::getFamily)
        .collect(Collectors.toList());
  }

  public String getFullName() {
    return firstName + " " + lastName;
  }
}

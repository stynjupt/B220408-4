package com.homebank.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "families")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Family {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, length = 100)
  private String name;

  @Column(nullable = false, length = 3)
  private String currency;

  @CreationTimestamp
  @Column(name = "created_at", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @UpdateTimestamp
  @Column(name = "updated_at")
  private LocalDateTime updatedAt;

  @OneToMany(mappedBy = "family", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<FamilyMembership> memberships = new ArrayList<>();

  @OneToMany(mappedBy = "family", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<Account> accounts = new ArrayList<>();

  @OneToMany(mappedBy = "family", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<Category> categories = new ArrayList<>();

  @OneToMany(mappedBy = "family", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<Budget> budgets = new ArrayList<>();

  @OneToMany(mappedBy = "family", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<Record> records = new ArrayList<>();

  @OneToMany(mappedBy = "family", cascade = CascadeType.ALL, orphanRemoval = true)
  @Builder.Default
  private List<FamilyInvitation> invitations = new ArrayList<>();

  public List<User> getActiveMembers() {
    return memberships.stream()
        .filter(FamilyMembership::isActiveMember)
        .map(FamilyMembership::getUser)
        .collect(Collectors.toList());
  }

  public List<User> getAdmins() {
    return memberships.stream()
        .filter(FamilyMembership::isActiveMember)
        .filter(FamilyMembership::isAdmin)
        .map(FamilyMembership::getUser)
        .collect(Collectors.toList());
  }

  public boolean hasMember(Long userId) {
    return memberships.stream()
        .anyMatch(
            m -> m.getUser().getId().equals(userId) && m.isActiveMember());
  }

  public boolean hasAdmin(Long userId) {
    return memberships.stream()
        .anyMatch(
            m ->
                m.getUser().getId().equals(userId)
                    && m.isActiveMember()
                    && m.isAdmin());
  }

  public int getActiveMemberCount() {
    return (int)
        memberships.stream().filter(FamilyMembership::isActiveMember).count();
  }
}

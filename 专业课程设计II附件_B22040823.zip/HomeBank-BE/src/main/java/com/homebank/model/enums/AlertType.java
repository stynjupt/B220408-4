package com.homebank.model.enums;

public enum AlertType {
  BUDGET_WARNING, 
  BUDGET_EXCEEDED 
}

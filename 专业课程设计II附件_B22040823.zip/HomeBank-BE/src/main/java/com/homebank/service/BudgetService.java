package com.homebank.service;

import com.homebank.dto.request.BudgetRequest;
import com.homebank.dto.request.UpdateBudgetRequest;
import com.homebank.dto.response.BudgetResponse;
import com.homebank.dto.response.BudgetStatusResponse;
import com.homebank.exception.FamilyAccessDeniedException;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Budget;
import com.homebank.model.Category;
import com.homebank.model.Family;
import com.homebank.model.User;
import com.homebank.model.enums.RecordType;
import com.homebank.repository.BudgetRepository;
import com.homebank.repository.CategoryRepository;
import com.homebank.repository.FamilyRepository;
import com.homebank.repository.RecordRepository;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class BudgetService {

  private final BudgetRepository budgetRepository;
  private final CategoryRepository categoryRepository;
  private final RecordRepository recordRepository;
  private final FamilyRepository familyRepository;
  private final FamilyMembershipService membershipService;

  @Transactional(readOnly = true)
  public List<BudgetResponse> getAllBudgets(Long userId, Long familyId) {
    membershipService.requireMember(userId, familyId);
    return budgetRepository.findByFamilyId(familyId).stream()
        .map(BudgetResponse::fromBudget)
        .collect(Collectors.toList());
  }

  @Transactional(readOnly = true)
  public BudgetResponse getBudgetById(Long budgetId, Long userId) {
    Budget budget =
        budgetRepository
            .findById(budgetId)
            .orElseThrow(() -> new ResourceNotFoundException("Budget not found"));

    membershipService.requireMember(userId, budget.getFamily().getId());

    return BudgetResponse.fromBudget(budget);
  }

  @Transactional
  public BudgetResponse createBudget(BudgetRequest request, Long userId, Long familyId) {
    log.info("User {} creating budget in family {}", userId, familyId);

    membershipService.requireAdmin(userId, familyId);

    Category category =
        categoryRepository
            .findById(request.getCategoryId())
            .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

    if (!category.getFamily().getId().equals(familyId)) {
      throw new FamilyAccessDeniedException("Category does not belong to your family");
    }

    if (request.getEndDate() != null && request.getEndDate().isBefore(request.getStartDate())) {
      throw new IllegalArgumentException("End date must be after start date");
    }

    Family family =
        familyRepository
            .findById(familyId)
            .orElseThrow(() -> new ResourceNotFoundException("Family not found"));

    User creator = membershipService.getUserById(userId);

    Budget budget =
        Budget.builder()
            .family(family)
            .category(category)
            .amount(request.getAmount())
            .period(request.getPeriod())
            .startDate(request.getStartDate())
            .endDate(request.getEndDate())
            .createdBy(creator)
            .build();

    budget = budgetRepository.save(budget);
    log.debug("Created budget {}", budget.getId());
    return BudgetResponse.fromBudget(budget);
  }

  @Transactional
  public BudgetResponse updateBudget(Long budgetId, UpdateBudgetRequest request, Long userId) {
    log.info("User {} updating budget {}", userId, budgetId);

    Budget budget =
        budgetRepository
            .findById(budgetId)
            .orElseThrow(() -> new ResourceNotFoundException("Budget not found"));

    membershipService.requireAdmin(userId, budget.getFamily().getId());

    if (request.getEndDate() != null && request.getEndDate().isBefore(request.getStartDate())) {
      throw new IllegalArgumentException("End date must be after start date");
    }

    budget.setAmount(request.getAmount());
    budget.setPeriod(request.getPeriod());
    budget.setStartDate(request.getStartDate());
    budget.setEndDate(request.getEndDate());

    budget = budgetRepository.save(budget);
    log.debug("Updated budget {}", budgetId);
    return BudgetResponse.fromBudget(budget);
  }

  @Transactional
  public void deleteBudget(Long budgetId, Long userId) {
    log.info("User {} deleting budget {}", userId, budgetId);

    Budget budget =
        budgetRepository
            .findById(budgetId)
            .orElseThrow(() -> new ResourceNotFoundException("Budget not found"));

    membershipService.requireAdmin(userId, budget.getFamily().getId());

    budgetRepository.delete(budget);
    log.debug("Deleted budget {}", budgetId);
  }

  @Transactional(readOnly = true)
  public BudgetStatusResponse getBudgetStatus(Long budgetId, Long userId) {
    Budget budget =
        budgetRepository
            .findById(budgetId)
            .orElseThrow(() -> new ResourceNotFoundException("Budget not found"));

    membershipService.requireMember(userId, budget.getFamily().getId());

        LocalDateTime startDateTime = budget.getStartDate().atStartOfDay();
        LocalDateTime endDateTime = budget.getEndDate() != null
                ? budget.getEndDate().atTime(LocalTime.MAX)
                : LocalDateTime.now();

        BigDecimal spentAmount = recordRepository.sumByCategoryIdAndTypeAndDateBetween(
                budget.getCategory().getId(),
                RecordType.EXPENSE,
                startDateTime,
                endDateTime
        );

        if (spentAmount == null) {
            spentAmount = BigDecimal.ZERO;
        }

        BigDecimal remainingAmount = budget.getAmount().subtract(spentAmount);

        Double usagePercentage = 0.0;
        if (budget.getAmount().compareTo(BigDecimal.ZERO) > 0) {
            usagePercentage = spentAmount
                    .multiply(BigDecimal.valueOf(100))
                    .divide(budget.getAmount(), 2, RoundingMode.HALF_UP)
                    .doubleValue();
        }

        Boolean isWarning = usagePercentage >= 80.0;
        Boolean isExceeded = usagePercentage >= 100.0;

        return BudgetStatusResponse.builder()
                .budgetId(budget.getId())
                .categoryName(budget.getCategory().getName())
                .budgetAmount(budget.getAmount())
                .spentAmount(spentAmount)
                .remainingAmount(remainingAmount)
                .usagePercentage(usagePercentage)
                .isWarning(isWarning)
                .isExceeded(isExceeded)
                .build();
    }

    @Transactional(readOnly = true)
    public List<BudgetStatusResponse> checkAllActiveBudgets() {
        LocalDate today = LocalDate.now();
        List<Budget> activeBudgets = budgetRepository.findActiveBudgets(today);

        return activeBudgets.stream()
                .map(budget -> {
                    LocalDateTime startDateTime = budget.getStartDate().atStartOfDay();
                    LocalDateTime endDateTime = budget.getEndDate() != null
                            ? budget.getEndDate().atTime(LocalTime.MAX)
                            : LocalDateTime.now();

                    BigDecimal spentAmount = recordRepository.sumByCategoryIdAndTypeAndDateBetween(
                            budget.getCategory().getId(),
                            RecordType.EXPENSE,
                            startDateTime,
                            endDateTime
                    );

                    if (spentAmount == null) {
                        spentAmount = BigDecimal.ZERO;
                    }

                    BigDecimal remainingAmount = budget.getAmount().subtract(spentAmount);

                    Double usagePercentage = 0.0;
                    if (budget.getAmount().compareTo(BigDecimal.ZERO) > 0) {
                        usagePercentage = spentAmount
                                .multiply(BigDecimal.valueOf(100))
                                .divide(budget.getAmount(), 2, RoundingMode.HALF_UP)
                                .doubleValue();
                    }

                    Boolean isWarning = usagePercentage >= 80.0;
                    Boolean isExceeded = usagePercentage >= 100.0;

                    return BudgetStatusResponse.builder()
                            .budgetId(budget.getId())
                            .categoryName(budget.getCategory().getName())
                            .budgetAmount(budget.getAmount())
                            .spentAmount(spentAmount)
                            .remainingAmount(remainingAmount)
                            .usagePercentage(usagePercentage)
                            .isWarning(isWarning)
                            .isExceeded(isExceeded)
                            .build();
                })
                .collect(Collectors.toList());
    }
}

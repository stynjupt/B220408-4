package com.homebank.service;

import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Family;
import com.homebank.model.FamilyInvitation;
import com.homebank.model.User;
import com.homebank.model.enums.InvitationStatus;
import com.homebank.model.enums.UserRole;
import com.homebank.repository.FamilyInvitationRepository;
import com.homebank.repository.FamilyRepository;
import com.homebank.repository.UserRepository;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class FamilyInvitationService {

  private final FamilyInvitationRepository invitationRepository;
  private final FamilyMembershipService membershipService;
  private final UserRepository userRepository;
  private final FamilyRepository familyRepository;

  @Value("${homebank.invitation.expiration-hours:72}")
  private int invitationExpirationHours;

  @Transactional
  public FamilyInvitation createInvitation(
      Long familyId, String inviteeEmail, UserRole role, Long inviterUserId) {
    log.info(
        "User {} creating invitation for {} to join family {}",
        inviterUserId,
        inviteeEmail,
        familyId);

    membershipService.requireAdmin(inviterUserId, familyId);

    if (invitationRepository.existsPendingInvitation(familyId, inviteeEmail, LocalDateTime.now())) {
      throw new IllegalStateException("A pending invitation already exists for this email");
    }

    User existingUser = userRepository.findByEmail(inviteeEmail).orElse(null);
    if (existingUser != null && membershipService.isMember(existingUser.getId(), familyId)) {
      throw new IllegalStateException("User is already a member of this family");
    }

    Family family =
        familyRepository
            .findById(familyId)
            .orElseThrow(() -> new ResourceNotFoundException("Family not found"));

    User inviter =
        userRepository
            .findById(inviterUserId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    String token = generateUniqueToken();

    FamilyInvitation invitation =
        FamilyInvitation.builder()
            .family(family)
            .inviter(inviter)
            .inviteeEmail(inviteeEmail)
            .role(role)
            .token(token)
            .status(InvitationStatus.PENDING)
            .expiresAt(LocalDateTime.now().plusHours(invitationExpirationHours))
            .build();

    invitation = invitationRepository.save(invitation);

    log.info("Created invitation {} for {} to join family {}", invitation.getId(), inviteeEmail, familyId);

    return invitation;
  }

  public FamilyInvitation save(FamilyInvitation invitation) {
    return invitationRepository.save(invitation);
  }

  @Transactional
  public FamilyInvitation acceptInvitation(String token, Long userId) {
    log.info("User {} accepting invitation with token {}", userId, token);

    FamilyInvitation invitation =
        invitationRepository
            .findByToken(token)
            .orElseThrow(() -> new ResourceNotFoundException("Invalid invitation token"));

    if (!invitation.isPending()) {
      throw new IllegalStateException("Invitation is not pending");
    }

    if (invitation.isExpired()) {
      invitation.markAsExpired();
      invitationRepository.save(invitation);
      throw new IllegalStateException("Invitation has expired");
    }

    User user =
        userRepository
            .findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    if (!user.getEmail().equalsIgnoreCase(invitation.getInviteeEmail())) {
      throw new IllegalStateException("Invitation email does not match user email");
    }

    if (membershipService.isMember(userId, invitation.getFamily().getId())) {
      throw new IllegalStateException("User is already a member of this family");
    }

    List<com.homebank.model.FamilyMembership> existingMemberships = membershipService.getUserMemberships(userId);

    if (!existingMemberships.isEmpty()) {
      boolean isAdminOfAnyFamily = existingMemberships.stream()
          .anyMatch(m -> m.getRole() == UserRole.FAMILY_ADMIN);

      if (!isAdminOfAnyFamily) {
        throw new IllegalStateException("User is already a member of another family. Cannot accept invitation.");
      }

      log.warn("User {} is a family admin, removing all existing memberships to accept new invitation", userId);
      for (com.homebank.model.FamilyMembership membership : existingMemberships) {
        Long familyId = membership.getFamily().getId();
        log.info("Deleting family {} and all related data for user {}", familyId, userId);

        familyRepository.deleteById(familyId);
      }
    }

    membershipService.createMembership(user, invitation.getFamily(), invitation.getRole());

    invitation.markAsAccepted();
    invitationRepository.save(invitation);

    log.info(
        "User {} accepted invitation and joined family {} as {}",
        userId,
        invitation.getFamily().getId(),
        invitation.getRole());

    return invitation;
  }

  @Transactional
  public void rejectInvitation(String token, Long userId) {
    log.info("User {} rejecting invitation with token {}", userId, token);

    FamilyInvitation invitation =
        invitationRepository
            .findByToken(token)
            .orElseThrow(() -> new ResourceNotFoundException("Invalid invitation token"));

    User user =
        userRepository
            .findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    if (!user.getEmail().equalsIgnoreCase(invitation.getInviteeEmail())) {
      throw new IllegalStateException("Invitation email does not match user email");
    }

    invitation.markAsRejected();
    invitationRepository.save(invitation);

    log.info("User {} rejected invitation {}", userId, invitation.getId());
  }

  @Transactional
  public void cancelInvitation(Long invitationId, Long operatorUserId) {
    log.info("User {} canceling invitation {}", operatorUserId, invitationId);

    FamilyInvitation invitation =
        invitationRepository
            .findById(invitationId)
            .orElseThrow(() -> new ResourceNotFoundException("Invitation not found"));

    membershipService.requireAdmin(operatorUserId, invitation.getFamily().getId());

    invitationRepository.delete(invitation);

    log.info("Invitation {} canceled", invitationId);
  }

  public List<FamilyInvitation> getFamilyPendingInvitations(Long familyId) {
    return invitationRepository.findPendingByFamilyId(familyId, LocalDateTime.now());
  }

  public List<FamilyInvitation> getUserPendingInvitations(String email) {
    return invitationRepository.findPendingByInviteeEmail(email, LocalDateTime.now());
  }

  public FamilyInvitation validateInvitation(String token) {
    FamilyInvitation invitation =
        invitationRepository
            .findByToken(token)
            .orElseThrow(() -> new ResourceNotFoundException("Invalid invitation token"));

    if (!invitation.isPending()) {
      throw new IllegalStateException("Invitation is not pending");
    }

    if (invitation.isExpired()) {
      invitation.markAsExpired();
      invitationRepository.save(invitation);
      throw new IllegalStateException("Invitation has expired");
    }

    return invitation;
  }

  @Transactional
  public void cleanupExpiredInvitations() {
    log.info("Starting invitation cleanup task");

    int expired = invitationRepository.expireOldInvitations(
        InvitationStatus.EXPIRED,
        InvitationStatus.PENDING,
        LocalDateTime.now());
    log.info("Expired {} old invitations", expired);

    int deleted = invitationRepository.deleteOldInvitations(LocalDateTime.now().minusDays(30));
    log.info("Deleted {} old invitation records", deleted);
  }

  private String generateUniqueToken() {
    SecureRandom random = new SecureRandom();
    String token;
    do {
      byte[] bytes = new byte[32];
      random.nextBytes(bytes);
      token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    } while (invitationRepository.existsByToken(token));
    return token;
  }
}

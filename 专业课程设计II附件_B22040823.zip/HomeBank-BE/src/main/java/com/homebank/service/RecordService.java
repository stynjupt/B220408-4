package com.homebank.service;

import com.homebank.dto.request.RecordRequest;
import com.homebank.dto.request.UpdateRecordRequest;
import com.homebank.dto.response.RecordResponse;
import com.homebank.exception.FamilyAccessDeniedException;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Account;
import com.homebank.model.Category;
import com.homebank.model.Family;
import com.homebank.model.Record;
import com.homebank.model.User;
import com.homebank.model.enums.RecordType;
import com.homebank.repository.AccountRepository;
import com.homebank.repository.CategoryRepository;
import com.homebank.repository.FamilyRepository;
import com.homebank.repository.RecordRepository;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class RecordService {

  private final RecordRepository recordRepository;
  private final AccountRepository accountRepository;
  private final CategoryRepository categoryRepository;
  private final FamilyRepository familyRepository;
  private final AccountPermissionService permissionService;
  private final FamilyMembershipService membershipService;
  private final AlertService alertService;

  @Transactional(readOnly = true)
  public Page<RecordResponse> getAllRecords(Long userId, Long familyId, Pageable pageable) {
    log.debug("Getting all records for user {} in family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    if (membershipService.isAdmin(userId, familyId)) {
      Page<Record> records = recordRepository.findByFamilyId(familyId, pageable);
      return records.map(RecordResponse::fromRecord);
    }

    List<Long> visibleAccountIds = permissionService.getVisibleAccountIds(userId);
    if (visibleAccountIds.isEmpty()) {
      return Page.empty(pageable);
    }

    Page<Record> records =
        recordRepository.findByFamilyIdAndAccountIdIn(familyId, visibleAccountIds, pageable);
    return records.map(RecordResponse::fromRecord);
  }

  @Transactional(readOnly = true)
  public Page<RecordResponse> getAllRecordsWithFilter(
      Long userId, Long familyId, Specification<Record> specification, Pageable pageable) {
    log.debug("Getting filtered records for user {} in family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    if (membershipService.isAdmin(userId, familyId)) {
      Page<Record> records = recordRepository.findAll(specification, pageable);
      return records.map(RecordResponse::fromRecord);
    }

    List<Long> visibleAccountIds = permissionService.getVisibleAccountIds(userId);
    if (visibleAccountIds.isEmpty()) {
      return Page.empty(pageable);
    }

    Specification<Record> finalSpec =
        specification.and(
            (root, query, cb) -> root.get("account").get("id").in(visibleAccountIds));

    Page<Record> records = recordRepository.findAll(finalSpec, pageable);
    return records.map(RecordResponse::fromRecord);
  }

  @Transactional(readOnly = true)
  public RecordResponse getRecordById(Long recordId, Long userId) {
    log.debug("User {} requesting record {}", userId, recordId);

    Record record =
        recordRepository
            .findById(recordId)
            .orElseThrow(() -> new ResourceNotFoundException("Record not found"));

    permissionService.requirePermission(
        userId, record.getAccount().getId(), record.getFamily().getId());

    return RecordResponse.fromRecord(record);
  }

  @Transactional
  public RecordResponse createRecord(RecordRequest request, Long userId, Long familyId) {
    log.info("User {} creating record in family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    Account account =
        accountRepository
            .findById(request.getAccountId())
            .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

    if (!account.getFamily().getId().equals(familyId)) {
      throw new FamilyAccessDeniedException("Account does not belong to this family");
    }

    permissionService.requireEditPermission(userId, account.getId(), familyId);

    Category category =
        categoryRepository
            .findById(request.getCategoryId())
            .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

    if (!category.getFamily().getId().equals(familyId)) {
      throw new FamilyAccessDeniedException("Category does not belong to this family");
    }

    User creator = membershipService.getUserById(userId);
    Family family =
        familyRepository
            .findById(familyId)
            .orElseThrow(() -> new ResourceNotFoundException("Family not found"));

    Record record =
        Record.builder()
            .user(creator)
            .family(family)
            .account(account)
            .category(category)
            .amount(request.getAmount())
            .type(request.getType())
            .label(request.getLabel())
            .note(request.getNote())
            .date(request.getDate())
            .build();

    BigDecimal balanceChange =
        request.getType() == RecordType.INCOME
            ? request.getAmount()
            : request.getAmount().negate();
    account.updateBalance(balanceChange);

    accountRepository.save(account);
    record = recordRepository.save(record);

    log.debug("Created record {} in family {}", record.getId(), familyId);

    if (request.getType() == RecordType.EXPENSE) {
      alertService.checkBudgetAndCreateAlertForCategory(familyId, category.getId());
    }

    return RecordResponse.fromRecord(record);
  }

  @Transactional
  public RecordResponse updateRecord(Long recordId, UpdateRecordRequest request, Long userId) {
    log.info("User {} updating record {}", userId, recordId);

    Record record =
        recordRepository
            .findById(recordId)
            .orElseThrow(() -> new ResourceNotFoundException("Record not found"));

    Long familyId = record.getFamily().getId();

    membershipService.requireMember(userId, familyId);

    boolean isCreator = record.getUser().getId().equals(userId);
    boolean isAdmin = membershipService.isAdmin(userId, familyId);
    boolean hasEditPermission =
        permissionService.hasEditPermission(userId, record.getAccount().getId());

    if (!isCreator && !isAdmin && !hasEditPermission) {
      throw new FamilyAccessDeniedException(
          "You don't have permission to update this record");
    }

    BigDecimal oldAmount = record.getAmount();
    RecordType oldType = record.getType();
    Account oldAccount = record.getAccount();

    if (request.getAccountId() != null
        && !request.getAccountId().equals(oldAccount.getId())) {
      Account newAccount =
          accountRepository
              .findById(request.getAccountId())
              .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

      if (!newAccount.getFamily().getId().equals(familyId)) {
        throw new FamilyAccessDeniedException("Account does not belong to this family");
      }

      permissionService.requireEditPermission(userId, newAccount.getId(), familyId);

      BigDecimal oldBalanceChange =
          oldType == RecordType.INCOME ? oldAmount.negate() : oldAmount;
      oldAccount.updateBalance(oldBalanceChange);
      accountRepository.save(oldAccount);

      record.setAccount(newAccount);
    }

    if (request.getCategoryId() != null
        && !request.getCategoryId().equals(record.getCategory().getId())) {
      Category newCategory =
          categoryRepository
              .findById(request.getCategoryId())
              .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

      if (!newCategory.getFamily().getId().equals(familyId)) {
        throw new FamilyAccessDeniedException("Category does not belong to this family");
      }

      record.setCategory(newCategory);
    }

    if (request.getAmount() != null) {
      record.setAmount(request.getAmount());
    }
    if (request.getType() != null) {
      record.setType(request.getType());
    }
    if (request.getLabel() != null && !request.getLabel().isEmpty()) {
      record.setLabel(request.getLabel());
    }
    if (request.getNote() != null) {
      record.setNote(request.getNote());
    }
    if (request.getDate() != null) {
      record.setDate(request.getDate());
    }

    BigDecimal oldBalanceChange =
        oldType == RecordType.INCOME ? oldAmount.negate() : oldAmount;
    record.getAccount().updateBalance(oldBalanceChange);

    BigDecimal newBalanceChange =
        record.getType() == RecordType.INCOME
            ? record.getAmount()
            : record.getAmount().negate();
    record.getAccount().updateBalance(newBalanceChange);

    accountRepository.save(record.getAccount());
    record = recordRepository.save(record);

    log.debug("Updated record {}", recordId);

    if (record.getType() == RecordType.EXPENSE) {
      alertService.checkBudgetAndCreateAlertForCategory(familyId, record.getCategory().getId());
    }

    return RecordResponse.fromRecord(record);
  }

  @Transactional
  public void deleteRecord(Long recordId, Long userId) {
    log.info("User {} deleting record {}", userId, recordId);

    Record record =
        recordRepository
            .findById(recordId)
            .orElseThrow(() -> new ResourceNotFoundException("Record not found"));

    Long familyId = record.getFamily().getId();

    membershipService.requireMember(userId, familyId);

    boolean isCreator = record.getUser().getId().equals(userId);
    boolean isAdmin = membershipService.isAdmin(userId, familyId);
    boolean hasEditPermission =
        permissionService.hasEditPermission(userId, record.getAccount().getId());

    if (!isCreator && !isAdmin && !hasEditPermission) {
      throw new FamilyAccessDeniedException(
          "You don't have permission to delete this record");
    }

    BigDecimal balanceChange =
        record.getType() == RecordType.INCOME
            ? record.getAmount().negate()
            : record.getAmount();
    record.getAccount().updateBalance(balanceChange);

    accountRepository.save(record.getAccount());
    recordRepository.delete(record);

    log.debug("Deleted record {}", recordId);
  }

  @Transactional(readOnly = true)
  public List<RecordResponse> getRecordsByAccountId(Long accountId, Long userId) {
    log.debug("User {} requesting records for account {}", userId, accountId);

    Account account =
        accountRepository
            .findById(accountId)
            .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

    permissionService.requirePermission(userId, accountId, account.getFamily().getId());

    return recordRepository.findByAccountId(accountId).stream()
        .map(RecordResponse::fromRecord)
        .collect(Collectors.toList());
  }
}

package com.homebank.service;

import com.homebank.dto.response.FamilyResponse;
import com.homebank.dto.response.UserResponse;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Family;
import com.homebank.model.FamilyMembership;
import com.homebank.repository.FamilyRepository;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class FamilyService {

  private final FamilyRepository familyRepository;
  private final FamilyMembershipService membershipService;

  @Transactional(readOnly = true)
  public FamilyResponse getFamilyById(Long familyId, Long userId) {
    log.debug("User {} requesting family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    Family family =
        familyRepository
            .findById(familyId)
            .orElseThrow(() -> new ResourceNotFoundException("Family not found"));

    return buildFamilyResponse(family);
  }

  @Transactional(readOnly = true)
  public List<UserResponse> getFamilyMembers(Long familyId, Long userId) {
    log.debug("User {} requesting members of family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    List<FamilyMembership> memberships = membershipService.getFamilyMembers(familyId);

    return memberships.stream().map(this::buildUserResponseFromMembership).collect(Collectors.toList());
  }

  @Transactional(readOnly = true)
  public List<FamilyResponse> getUserFamilies(Long userId) {
    log.debug("Getting all families for user {}", userId);

    List<FamilyMembership> memberships = membershipService.getUserMemberships(userId);

    return memberships.stream()
        .map(m -> buildFamilyResponse(m.getFamily()))
        .collect(Collectors.toList());
  }

  @Transactional
  public FamilyResponse updateFamily(Long familyId, String name, String currency, Long userId) {
    log.info("User {} updating family {}", userId, familyId);

    membershipService.requireAdmin(userId, familyId);

    Family family =
        familyRepository
            .findById(familyId)
            .orElseThrow(() -> new ResourceNotFoundException("Family not found"));

    if (name != null && !name.isEmpty()) {
      family.setName(name);
    }
    if (currency != null && !currency.isEmpty()) {
      family.setCurrency(currency);
    }

    family = familyRepository.save(family);
    log.debug("Updated family {}", familyId);

    return buildFamilyResponse(family);
  }

  private FamilyResponse buildFamilyResponse(Family family) {
    return FamilyResponse.builder()
        .id(family.getId())
        .name(family.getName())
        .currency(family.getCurrency())
        .createdAt(family.getCreatedAt())
        .build();
  }

  private UserResponse buildUserResponseFromMembership(FamilyMembership membership) {
    return UserResponse.builder()
        .id(membership.getUser().getId())
        .familyId(membership.getFamily().getId())
        .firstName(membership.getUser().getFirstName())
        .lastName(membership.getUser().getLastName())
        .email(membership.getUser().getEmail())
        .currency(membership.getFamily().getCurrency())
        .role(membership.getRole())
        .isActive(membership.getIsActive())
        .createdAt(membership.getUser().getCreatedAt())
        .build();
  }
}

package com.homebank.service;

import com.homebank.dto.request.AccountRequest;
import com.homebank.dto.response.AccountPermissionInfo;
import com.homebank.dto.response.AccountResponse;
import com.homebank.exception.ResourceNotFoundException;
import com.homebank.model.Account;
import com.homebank.model.Family;
import com.homebank.model.User;
import com.homebank.model.enums.AccountPermissionType;
import com.homebank.repository.AccountRepository;
import com.homebank.repository.FamilyRepository;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountService {

  private final AccountRepository accountRepository;
  private final FamilyRepository familyRepository;
  private final AccountPermissionService permissionService;
  private final FamilyMembershipService membershipService;

  @Transactional(readOnly = true)
  public List<AccountResponse> getUserVisibleAccounts(Long userId, Long familyId) {
    log.debug("Getting visible accounts for user {} in family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    boolean isAdmin = membershipService.isAdmin(userId, familyId);

    if (isAdmin) {
      return accountRepository.findByFamilyId(familyId).stream()
          .map(account -> enrichWithPermissionInfo(account, userId, isAdmin))
          .collect(Collectors.toList());
    }

    List<Long> visibleAccountIds = permissionService.getVisibleAccountIds(userId);
    if (visibleAccountIds.isEmpty()) {
      return List.of();
    }

    return accountRepository.findAllById(visibleAccountIds).stream()
        .filter(account -> account.getFamily().getId().equals(familyId))
        .map(account -> enrichWithPermissionInfo(account, userId, false))
        .collect(Collectors.toList());
  }

  private AccountResponse enrichWithPermissionInfo(
      Account account, Long userId, boolean isAdmin) {
    AccountResponse response = AccountResponse.fromAccount(account);

    if (isAdmin) {
      response.setCurrentUserPermission(AccountPermissionType.EDIT);
    } else {
      
      AccountPermissionType permission = account.getUserPermissionType(userId);
      response.setCurrentUserPermission(permission);
    }

    if (isAdmin) {
      List<AccountPermissionInfo> permissionInfos =
          account.getPermissions().stream()
              .map(AccountPermissionInfo::fromAccountPermission)
              .collect(Collectors.toList());
      response.setPermissions(permissionInfos);
    }

    return response;
  }

  @Transactional(readOnly = true)
  public List<AccountResponse> getAllUserVisibleAccounts(Long userId) {
    log.debug("Getting all visible accounts for user {}", userId);

    List<Long> familyIds = membershipService.getUserFamilyIds(userId);
    return familyIds.stream()
        .flatMap(familyId -> getUserVisibleAccounts(userId, familyId).stream())
        .collect(Collectors.toList());
  }

  @Transactional(readOnly = true)
  public AccountResponse getAccountById(Long accountId, Long userId) {
    log.debug("User {} requesting account {}", userId, accountId);

    Account account =
        accountRepository
            .findById(accountId)
            .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

    permissionService.requirePermission(userId, accountId, account.getFamily().getId());

    boolean isAdmin = membershipService.isAdmin(userId, account.getFamily().getId());
    return enrichWithPermissionInfo(account, userId, isAdmin);
  }

  @Transactional
  public AccountResponse createAccount(AccountRequest request, Long userId, Long familyId) {
    log.info("User {} creating account in family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    Family family =
        familyRepository
            .findById(familyId)
            .orElseThrow(() -> new ResourceNotFoundException("Family not found"));

    User creator =
        membershipService.getUserById(userId); 

    Account account =
        Account.builder()
            .family(family)
            .name(request.getName())
            .balance(request.getBalance())
            .currency(request.getCurrency())
            .color(request.getColor() != null ? request.getColor() : "#1976D2")
            .icon(request.getIcon() != null ? request.getIcon() : "mdi-wallet")
            .includeInStatistics(
                request.getIncludeInStatistics() != null ? request.getIncludeInStatistics() : true)
            .build();

    account = accountRepository.save(account);
    log.debug("Created account {}", account.getId());

    permissionService.grantCreatorPermission(account, creator);
    log.debug("Granted EDIT permission to creator {}", userId);

    return AccountResponse.fromAccount(account);
  }

  @Transactional
  public AccountResponse updateAccount(Long accountId, AccountRequest request, Long userId) {
    log.info("User {} updating account {}", userId, accountId);

    Account account =
        accountRepository
            .findById(accountId)
            .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

    permissionService.requireEditPermission(userId, accountId, account.getFamily().getId());

    account.setName(request.getName());
    account.setBalance(request.getBalance());
    account.setCurrency(request.getCurrency());
    account.setColor(request.getColor());
    account.setIcon(request.getIcon());
    account.setIncludeInStatistics(request.getIncludeInStatistics());

    account = accountRepository.save(account);
    log.debug("Updated account {}", accountId);

    return AccountResponse.fromAccount(account);
  }

  @Transactional
  public void deleteAccount(Long accountId, Long userId) {
    log.info("User {} deleting account {}", userId, accountId);

    Account account =
        accountRepository
            .findById(accountId)
            .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

    permissionService.requireEditPermission(userId, accountId, account.getFamily().getId());

    accountRepository.delete(account);
    log.debug("Deleted account {}", accountId);
  }

  @Transactional(readOnly = true)
  public List<AccountResponse> getFamilyAccounts(Long familyId, Long userId) {
    log.debug("User {} requesting all accounts for family {}", userId, familyId);

    membershipService.requireAdmin(userId, familyId);

    return accountRepository.findByFamilyId(familyId).stream()
        .map(AccountResponse::fromAccount)
        .collect(Collectors.toList());
  }

  @Transactional(readOnly = true)
  public List<AccountResponse> getUserEditableAccounts(Long userId, Long familyId) {
    log.debug("Getting editable accounts for user {} in family {}", userId, familyId);

    membershipService.requireMember(userId, familyId);

    if (membershipService.isAdmin(userId, familyId)) {
      return accountRepository.findByFamilyId(familyId).stream()
          .map(AccountResponse::fromAccount)
          .collect(Collectors.toList());
    }

    List<Long> editableAccountIds = permissionService.getEditableAccountIds(userId);
    if (editableAccountIds.isEmpty()) {
      return List.of();
    }

    return accountRepository.findAllById(editableAccountIds).stream()
        .filter(account -> account.getFamily().getId().equals(familyId))
        .map(AccountResponse::fromAccount)
        .collect(Collectors.toList());
  }
}

package com.homebank.dto.response;

import com.homebank.model.Record;
import com.homebank.model.enums.RecordType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecordResponse {

  private Long id;
  private Long userId;
  private String userFirstName; 
  private String userLastName; 
  private String userEmail; 
  private AccountReducedResponse account;
  private CategoryResponse category;
  private BigDecimal amount;
  private RecordType type;
  private String label;
  private String note;
  private LocalDateTime date;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;

  public static RecordResponse fromRecord(Record record) {
    return RecordResponse.builder()
        .id(record.getId())
        .userId(record.getUser().getId())
        .userFirstName(record.getUser().getFirstName())
        .userLastName(record.getUser().getLastName())
        .userEmail(record.getUser().getEmail())
        .account(AccountReducedResponse.fromAccount(record.getAccount()))
        .category(CategoryResponse.fromCategory(record.getCategory()))
        .amount(record.getAmount())
        .type(record.getType())
        .label(record.getLabel())
        .note(record.getNote())
        .date(record.getDate())
        .createdAt(record.getCreatedAt())
        .updatedAt(record.getUpdatedAt())
        .build();
  }
}

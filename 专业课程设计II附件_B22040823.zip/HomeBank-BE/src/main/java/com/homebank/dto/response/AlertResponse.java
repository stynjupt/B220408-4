package com.homebank.dto.response;

import com.homebank.model.Alert;
import com.homebank.model.enums.AlertType;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AlertResponse {

  private Long id;
  private Long budgetId;
  private Long userId;
  private String message;
  private AlertType type;
  private Integer thresholdPercentage;
  private Boolean isRead;
  private LocalDateTime createdAt;

  public static AlertResponse fromAlert(Alert alert) {
    return AlertResponse.builder()
        .id(alert.getId())
        .budgetId(alert.getBudget().getId())
        .userId(alert.getUser().getId())
        .message(alert.getMessage())
        .type(alert.getType())
        .thresholdPercentage(alert.getThresholdPercentage())
        .isRead(alert.getIsRead())
        .createdAt(alert.getCreatedAt())
        .build();
  }
}

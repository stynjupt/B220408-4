package com.homebank.dto.response;

import com.homebank.model.Account;
import com.homebank.model.enums.AccountPermissionType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountResponse {

  private Long id;
  private Long familyId;
  private String name;
  private BigDecimal balance;
  private String currency;
  private String color;
  private String icon;
  private Boolean includeInStatistics;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;

  private AccountPermissionType currentUserPermission;
  private List<AccountPermissionInfo> permissions;

  public static AccountResponse fromAccount(Account account) {
    return AccountResponse.builder()
        .id(account.getId())
        .familyId(account.getFamily().getId())
        .name(account.getName())
        .balance(account.getBalance())
        .currency(account.getCurrency())
        .color(account.getColor())
        .icon(account.getIcon())
        .includeInStatistics(account.getIncludeInStatistics())
        .createdAt(account.getCreatedAt())
        .updatedAt(account.getUpdatedAt())
        .build();
  }
}

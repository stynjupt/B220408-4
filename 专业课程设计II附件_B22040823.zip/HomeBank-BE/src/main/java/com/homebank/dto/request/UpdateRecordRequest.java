package com.homebank.dto.request;

import com.homebank.model.enums.RecordType;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateRecordRequest {

  private Long accountId;

  private Long categoryId;

  private BigDecimal amount;

  private RecordType type;

  @Size(min = 1, max = 100, message = "Label must be between 1 and 100 characters")
  private String label;

  @Size(max = 500, message = "Note must not exceed 500 characters")
  private String note;

  private LocalDateTime date;
}

package com.homebank.dto.response;

import com.homebank.model.enums.UserRole;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {

  private Long id;
  private Long familyId;
  private String firstName;
  private String lastName;
  private String email;
  private String currency;
  private UserRole role;
  private Boolean isActive;
  private LocalDateTime createdAt;
  private List<Long> accountIds;

  private List<FamilyMembershipSummary> memberships;

  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public static class FamilyMembershipSummary {
    private Long familyId;
    private String familyName;
    private UserRole role;
    private Boolean isActive;
  }
}

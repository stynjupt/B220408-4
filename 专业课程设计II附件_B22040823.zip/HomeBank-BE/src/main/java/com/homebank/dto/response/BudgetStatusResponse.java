package com.homebank.dto.response;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BudgetStatusResponse {

  private Long budgetId;
  private String categoryName;
  private BigDecimal budgetAmount;
  private BigDecimal spentAmount;
  private BigDecimal remainingAmount;
  private Double usagePercentage;
  private Boolean isWarning; 
  private Boolean isExceeded; 
}

package com.homebank.dto.response;

import com.homebank.model.Budget;
import com.homebank.model.enums.BudgetPeriod;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BudgetResponse {

  private Long id;
  private Long familyId;
  private Long categoryId;
  private String categoryName;
  private BigDecimal amount;
  private BudgetPeriod period;
  private LocalDate startDate;
  private LocalDate endDate;
  private Long createdById;
  private String createdByName;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;

  public static BudgetResponse fromBudget(Budget budget) {
    return BudgetResponse.builder()
        .id(budget.getId())
        .familyId(budget.getFamily().getId())
        .categoryId(budget.getCategory().getId())
        .categoryName(budget.getCategory().getName())
        .amount(budget.getAmount())
        .period(budget.getPeriod())
        .startDate(budget.getStartDate())
        .endDate(budget.getEndDate())
        .createdById(budget.getCreatedBy().getId())
        .createdByName(
            budget.getCreatedBy().getFirstName() + " " + budget.getCreatedBy().getLastName())
        .createdAt(budget.getCreatedAt())
        .updatedAt(budget.getUpdatedAt())
        .build();
  }
}

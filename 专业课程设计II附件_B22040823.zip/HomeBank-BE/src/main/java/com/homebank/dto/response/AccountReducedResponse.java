package com.homebank.dto.response;

import com.homebank.model.Account;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountReducedResponse {

  private Long id;
  private String name;
  private String currency;
  private String color;
  private String icon;

  public static AccountReducedResponse fromAccount(Account account) {
    return AccountReducedResponse.builder()
        .id(account.getId())
        .name(account.getName())
        .currency(account.getCurrency())
        .color(account.getColor())
        .icon(account.getIcon())
        .build();
  }
}

package com.homebank.dto.request;

import com.homebank.model.enums.UserRole;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateInvitationRequest {

  @NotBlank(message = "Invitee email is required")
  @Email(message = "Invalid email format")
  private String inviteeEmail;

  @Builder.Default
  private UserRole role = UserRole.FAMILY_MEMBER;
}

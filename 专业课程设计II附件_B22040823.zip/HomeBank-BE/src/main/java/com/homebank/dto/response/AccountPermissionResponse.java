package com.homebank.dto.response;

import com.homebank.model.enums.AccountPermissionType;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountPermissionResponse {
  private Long id;
  private Long userId;
  private String userEmail;
  private String userFirstName;
  private String userLastName;
  private AccountPermissionType permission;
  private LocalDateTime grantedAt;
  private Long grantedById;
  private String grantedByEmail;
}

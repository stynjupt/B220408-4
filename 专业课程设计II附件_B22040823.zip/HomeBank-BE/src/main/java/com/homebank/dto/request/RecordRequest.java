package com.homebank.dto.request;

import com.homebank.model.enums.RecordType;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecordRequest {

  @NotNull(message = "Account ID is required")
  private Long accountId;

  @NotNull(message = "Category ID is required")
  private Long categoryId;

  @NotNull(message = "Amount is required")
  private BigDecimal amount;

  @NotNull(message = "Record type is required")
  private RecordType type;

  @NotBlank(message = "Label is required")
  @Size(min = 1, max = 100, message = "Label must be between 1 and 100 characters")
  private String label;

  @Size(max = 500, message = "Note must not exceed 500 characters")
  private String note;

  @NotNull(message = "Date is required")
  private LocalDateTime date;
}

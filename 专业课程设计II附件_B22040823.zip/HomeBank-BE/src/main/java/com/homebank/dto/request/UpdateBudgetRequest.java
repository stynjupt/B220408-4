package com.homebank.dto.request;

import com.homebank.model.enums.BudgetPeriod;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateBudgetRequest {

  @NotNull(message = "Budget amount is required")
  @DecimalMin(value = "0.01", message = "Budget amount must be greater than 0")
  private BigDecimal amount;

  @NotNull(message = "Budget period is required")
  private BudgetPeriod period;

  @NotNull(message = "Start date is required")
  private LocalDate startDate;

  private LocalDate endDate;
}

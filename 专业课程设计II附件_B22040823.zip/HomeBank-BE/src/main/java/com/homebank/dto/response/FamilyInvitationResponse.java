package com.homebank.dto.response;

import com.homebank.model.enums.InvitationStatus;
import com.homebank.model.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FamilyInvitationResponse {

  private Long id;
  private Long familyId;
  private String familyName;
  private String inviteeEmail;
  private UserRole role;
  private String token;
  private InvitationStatus status;
  private LocalDateTime expiresAt;
  private LocalDateTime createdAt;
}

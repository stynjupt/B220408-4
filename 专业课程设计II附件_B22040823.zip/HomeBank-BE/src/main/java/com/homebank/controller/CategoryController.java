package com.homebank.controller;

import com.homebank.dto.response.CategoryAnalyticResponse;
import com.homebank.dto.response.CategoryResponse;
import com.homebank.model.User;
import com.homebank.service.AnalyticService;
import com.homebank.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/families/{familyId}/categories")
@RequiredArgsConstructor
@Tag(name = "Category", description = "分类管理API")
@SecurityRequirement(name = "bearer-key")
public class CategoryController {

  private final CategoryService categoryService;
  private final AnalyticService analyticService;

  @GetMapping
  @Operation(summary = "获取所有分类", description = "获取家庭的所有分类")
  public ResponseEntity<List<CategoryResponse>> getFamilyCategories(
      @PathVariable Long familyId, @AuthenticationPrincipal User currentUser) {
    List<CategoryResponse> categories = categoryService.getFamilyCategories(familyId);
    return ResponseEntity.ok(categories);
  }

  @GetMapping("/analytics")
  @Operation(summary = "获取分类统计分析", description = "获取按分类分组的统计分析。支持scope_user_id过滤特定成员数据")
  public ResponseEntity<List<CategoryAnalyticResponse>> getCategoryAnalytic(
      @PathVariable Long familyId,
      @AuthenticationPrincipal User currentUser,
      @Parameter(description = "范围用户ID（可选，null=全家庭，非null=特定成员）") @RequestParam(required = false) Long scope_user_id,
      @Parameter(description = "开始日期（包含）") @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateGe,
      @Parameter(description = "结束日期（不包含）") @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateLt) {

    LocalDateTime dateGeTime = dateGe != null ? dateGe.atStartOfDay() : null;
    LocalDateTime dateLtTime = dateLt != null ? dateLt.atStartOfDay() : null;

    List<CategoryAnalyticResponse> analytics = analyticService.getCategoryAnalytic(
        currentUser.getId(), familyId, scope_user_id, dateGeTime, dateLtTime);
    return ResponseEntity.ok(analytics);
  }
}

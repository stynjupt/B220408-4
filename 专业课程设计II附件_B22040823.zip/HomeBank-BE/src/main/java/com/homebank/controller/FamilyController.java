package com.homebank.controller;

import com.homebank.dto.response.FamilyResponse;
import com.homebank.dto.response.UserResponse;
import com.homebank.model.FamilyMembership;
import com.homebank.model.User;
import com.homebank.model.enums.UserRole;
import com.homebank.service.FamilyMembershipService;
import com.homebank.service.FamilyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/families")
@RequiredArgsConstructor
@Tag(name = "Family", description = "家庭管理API")
@SecurityRequirement(name = "bearer-key")
public class FamilyController {

  private final FamilyService familyService;
  private final FamilyMembershipService membershipService;

  @GetMapping
  @Operation(summary = "获取用户的所有家庭", description = "获取当前用户所属的所有家庭")
  public ResponseEntity<List<FamilyResponse>> getUserFamilies(
      @AuthenticationPrincipal User currentUser) {
    List<FamilyResponse> families = familyService.getUserFamilies(currentUser.getId());
    return ResponseEntity.ok(families);
  }

  @GetMapping("/{familyId}")
  @Operation(summary = "获取家庭详情", description = "根据ID获取家庭信息")
  public ResponseEntity<FamilyResponse> getFamilyById(
      @PathVariable Long familyId, @AuthenticationPrincipal User currentUser) {
    FamilyResponse response = familyService.getFamilyById(familyId, currentUser.getId());
    return ResponseEntity.ok(response);
  }

  @PutMapping("/{familyId}")
  @Operation(summary = "更新家庭信息", description = "更新家庭名称和货币（仅管理员）")
  public ResponseEntity<FamilyResponse> updateFamily(
      @PathVariable Long familyId,
      @RequestParam(required = false) String name,
      @RequestParam(required = false) String currency,
      @AuthenticationPrincipal User currentUser) {
    FamilyResponse response = familyService.updateFamily(familyId, name, currency, currentUser.getId());
    return ResponseEntity.ok(response);
  }

  @GetMapping("/{familyId}/members")
  @Operation(summary = "获取家庭成员", description = "获取家庭的所有成员")
  public ResponseEntity<List<UserResponse>> getFamilyMembers(
      @PathVariable Long familyId, @AuthenticationPrincipal User currentUser) {
    List<UserResponse> members = familyService.getFamilyMembers(familyId, currentUser.getId());
    return ResponseEntity.ok(members);
  }

  @PutMapping("/{familyId}/members/{memberId}/role")
  @Operation(summary = "更新成员角色", description = "更新成员的角色（仅管理员）")
  public ResponseEntity<FamilyMembership> updateMemberRole(
      @PathVariable Long familyId,
      @PathVariable Long memberId,
      @RequestParam UserRole newRole,
      @AuthenticationPrincipal User currentUser) {
    FamilyMembership membership = membershipService.updateMemberRole(familyId, memberId, newRole, currentUser.getId());
    return ResponseEntity.ok(membership);
  }

  @PostMapping("/{familyId}/members/{memberId}/deactivate")
  @Operation(summary = "禁用成员", description = "禁用家庭成员（软删除，仅管理员）")
  public ResponseEntity<Void> deactivateMember(
      @PathVariable Long familyId,
      @PathVariable Long memberId,
      @AuthenticationPrincipal User currentUser) {
    membershipService.deactivateMember(familyId, memberId, currentUser.getId());
    return ResponseEntity.noContent().build();
  }

  @PostMapping("/{familyId}/members/{memberId}/activate")
  @Operation(summary = "激活成员", description = "激活已禁用的成员（仅管理员）")
  public ResponseEntity<Void> activateMember(
      @PathVariable Long familyId,
      @PathVariable Long memberId,
      @AuthenticationPrincipal User currentUser) {
    membershipService.activateMember(familyId, memberId, currentUser.getId());
    return ResponseEntity.noContent().build();
  }

  @DeleteMapping("/{familyId}/members/{memberId}")
  @Operation(summary = "移除成员", description = "从家庭中永久移除成员（仅管理员）")
  public ResponseEntity<Void> removeMember(
      @PathVariable Long familyId,
      @PathVariable Long memberId,
      @AuthenticationPrincipal User currentUser) {
    membershipService.removeMember(familyId, memberId, currentUser.getId());
    return ResponseEntity.noContent().build();
  }

  @PostMapping("/{familyId}/leave")
  @Operation(summary = "离开家庭", description = "用户主动离开家庭")
  public ResponseEntity<Void> leaveFamily(
      @PathVariable Long familyId, @AuthenticationPrincipal User currentUser) {
    membershipService.leaveFam(currentUser.getId(), familyId);
    return ResponseEntity.noContent().build();
  }
}

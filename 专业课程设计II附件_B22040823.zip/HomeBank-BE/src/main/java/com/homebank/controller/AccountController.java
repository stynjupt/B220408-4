package com.homebank.controller;

import com.homebank.dto.request.AccountRequest;
import com.homebank.dto.response.AccountResponse;
import com.homebank.model.AccountPermission;
import com.homebank.model.User;
import com.homebank.model.enums.AccountPermissionType;
import com.homebank.service.AccountPermissionService;
import com.homebank.service.AccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/families/{familyId}/accounts")
@RequiredArgsConstructor
@Tag(name = "Account", description = "账户管理API")
@SecurityRequirement(name = "bearer-key")
public class AccountController {

  private final AccountService accountService;
  private final AccountPermissionService permissionService;

  @GetMapping
  @Operation(summary = "获取家庭账户", description = "获取用户在该家庭可见的所有账户")
  public ResponseEntity<List<AccountResponse>> getFamilyAccounts(
      @PathVariable Long familyId, @AuthenticationPrincipal User currentUser) {
    List<AccountResponse> accounts = accountService.getUserVisibleAccounts(currentUser.getId(), familyId);
    return ResponseEntity.ok(accounts);
  }

  @GetMapping("/editable")
  @Operation(summary = "获取可编辑账户", description = "获取用户可编辑的账户列表")
  public ResponseEntity<List<AccountResponse>> getEditableAccounts(
      @PathVariable Long familyId, @AuthenticationPrincipal User currentUser) {
    List<AccountResponse> accounts = accountService.getUserEditableAccounts(currentUser.getId(), familyId);
    return ResponseEntity.ok(accounts);
  }

  @GetMapping("/{accountId}")
  @Operation(summary = "根据ID获取账户", description = "根据ID获取账户详情（需要可见权限）")
  public ResponseEntity<AccountResponse> getAccountById(
      @PathVariable Long familyId,
      @PathVariable Long accountId,
      @AuthenticationPrincipal User currentUser) {
    AccountResponse account = accountService.getAccountById(accountId, currentUser.getId());
    return ResponseEntity.ok(account);
  }

  @PostMapping
  @Operation(summary = "创建账户", description = "在家庭下创建新账户")
  public ResponseEntity<AccountResponse> createAccount(
      @PathVariable Long familyId,
      @Valid @RequestBody AccountRequest request,
      @AuthenticationPrincipal User currentUser) {
    AccountResponse account = accountService.createAccount(request, currentUser.getId(), familyId);
    return ResponseEntity.status(HttpStatus.CREATED).body(account);
  }

  @PutMapping("/{accountId}")
  @Operation(summary = "更新账户", description = "更新账户（需要编辑权限）")
  public ResponseEntity<AccountResponse> updateAccount(
      @PathVariable Long familyId,
      @PathVariable Long accountId,
      @Valid @RequestBody AccountRequest request,
      @AuthenticationPrincipal User currentUser) {
    AccountResponse account = accountService.updateAccount(accountId, request, currentUser.getId());
    return ResponseEntity.ok(account);
  }

  @DeleteMapping("/{accountId}")
  @Operation(summary = "删除账户", description = "删除账户（需要编辑权限）")
  public ResponseEntity<Void> deleteAccount(
      @PathVariable Long familyId,
      @PathVariable Long accountId,
      @AuthenticationPrincipal User currentUser) {
    accountService.deleteAccount(accountId, currentUser.getId());
    return ResponseEntity.noContent().build();
  }

  @GetMapping("/{accountId}/permissions")
  @Operation(summary = "获取账户权限", description = "获取账户的所有权限记录")
  public ResponseEntity<List<com.homebank.dto.response.AccountPermissionResponse>> getAccountPermissions(
      @PathVariable Long familyId,
      @PathVariable Long accountId,
      @AuthenticationPrincipal User currentUser) {
    List<AccountPermission> permissions = permissionService.getAccountPermissions(accountId);

    List<com.homebank.dto.response.AccountPermissionResponse> response = permissions.stream()
        .map(p -> com.homebank.dto.response.AccountPermissionResponse.builder()
            .id(p.getId())
            .userId(p.getUser().getId())
            .userEmail(p.getUser().getEmail())
            .userFirstName(p.getUser().getFirstName())
            .userLastName(p.getUser().getLastName())
            .permission(p.getPermission())
            .grantedAt(p.getGrantedAt())
            .grantedById(p.getGrantedBy() != null ? p.getGrantedBy().getId() : null)
            .grantedByEmail(p.getGrantedBy() != null ? p.getGrantedBy().getEmail() : null)
            .build())
        .collect(java.util.stream.Collectors.toList());

    return ResponseEntity.ok(response);
  }

  @PostMapping("/{accountId}/permissions")
  @Operation(summary = "授予权限", description = "为用户授予账户权限")
  public ResponseEntity<AccountPermission> grantPermission(
      @PathVariable Long familyId,
      @PathVariable Long accountId,
      @RequestParam Long targetUserId,
      @RequestParam AccountPermissionType permissionType,
      @AuthenticationPrincipal User currentUser) {
    AccountPermission permission = permissionService.grantPermission(
        accountId, targetUserId, permissionType, currentUser.getId());
    return ResponseEntity.status(HttpStatus.CREATED).body(permission);
  }

  @DeleteMapping("/{accountId}/permissions/{targetUserId}")
  @Operation(summary = "撤销权限", description = "撤销用户的账户权限")
  public ResponseEntity<Void> revokePermission(
      @PathVariable Long familyId,
      @PathVariable Long accountId,
      @PathVariable Long targetUserId,
      @AuthenticationPrincipal User currentUser) {
    permissionService.revokePermission(accountId, targetUserId, currentUser.getId());
    return ResponseEntity.noContent().build();
  }
}

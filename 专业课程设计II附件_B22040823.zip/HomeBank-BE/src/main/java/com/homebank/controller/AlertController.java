package com.homebank.controller;

import com.homebank.dto.response.AlertResponse;
import com.homebank.model.User;
import com.homebank.service.AlertService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/alerts")
@RequiredArgsConstructor
@Tag(name = "Alert", description = "预算提醒管理API")
@SecurityRequirement(name = "bearer-key")
public class AlertController {

  private final AlertService alertService;

  @GetMapping
  @Operation(summary = "获取所有提醒", description = "获取当前用户的所有预算提醒")
  public ResponseEntity<List<AlertResponse>> getAllAlerts(
      @AuthenticationPrincipal User currentUser) {
    List<AlertResponse> alerts = alertService.getAllAlerts(currentUser.getId());
    return ResponseEntity.ok(alerts);
  }

  @GetMapping("/unread")
  @Operation(summary = "获取未读提醒", description = "获取当前用户的所有未读预算提醒")
  public ResponseEntity<List<AlertResponse>> getUnreadAlerts(
      @AuthenticationPrincipal User currentUser) {
    List<AlertResponse> alerts = alertService.getUnreadAlerts(currentUser.getId());
    return ResponseEntity.ok(alerts);
  }

  @PutMapping("/{id}/read")
  @Operation(summary = "标记提醒为已读", description = "将预算提醒标记为已读")
  public ResponseEntity<AlertResponse> markAsRead(
      @PathVariable Long id, @AuthenticationPrincipal User currentUser) {
    AlertResponse alert = alertService.markAsRead(id, currentUser.getId());
    return ResponseEntity.ok(alert);
  }

  @DeleteMapping("/{id}")
  @Operation(summary = "删除提醒", description = "删除预算提醒")
  public ResponseEntity<Void> deleteAlert(
      @PathVariable Long id, @AuthenticationPrincipal User currentUser) {
    alertService.deleteAlert(id, currentUser.getId());
    return ResponseEntity.noContent().build();
  }

  @PostMapping("/trigger-check")
  @Operation(summary = "触发预算检查（仅用于测试）", description = "手动触发预算检查和提醒创建，用于测试目的")
  public ResponseEntity<String> triggerBudgetCheck() {
    alertService.checkBudgetsAndCreateAlerts();
    return ResponseEntity.ok("预算检查已触发成功。已为超过阈值的预算创建提醒。");
  }
}

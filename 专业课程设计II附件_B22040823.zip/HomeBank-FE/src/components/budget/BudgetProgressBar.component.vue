<template>
  <div>
    <v-progress-linear
      :value="percentage"
      :color="progressColor"
      height="20"
      rounded
    >
      <template v-slot:default>
        <strong class="white--text">{{ percentage.toFixed(1) }}%</strong>
      </template>
    </v-progress-linear>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";

@Component
export default class BudgetProgressBar extends Vue {
  @Prop({ required: true }) used!: number;
  @Prop({ required: true }) total!: number;
  @Prop({ required: true }) percentage!: number;

  get progressColor(): string {
    if (this.percentage >= 100) return "red";
    if (this.percentage >= 80) return "orange";
    if (this.percentage >= 50) return "yellow darken-2";
    return "green";
  }
}
</script>

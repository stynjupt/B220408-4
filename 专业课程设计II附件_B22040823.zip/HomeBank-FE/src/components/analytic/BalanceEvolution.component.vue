<template>
  <div class="container">
    <h2 v-if="!balanceEvolutionLoading" class="main primary--text">余额变化</h2>

    <div v-if="!balanceEvolutionLoading" class="chart-wrapper">
      <apex-chart
        :options="chartData.options"
        :series="chartData.series"
        type="area"
        height="350"
        width="100%"
      />
    </div>

    <v-skeleton-loader v-else type="image" class="skeleton" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import userApi, { TimeSeriesEntry } from "@/api/userApi";
import { Action, Getter } from "vuex-class";
import errorMessage from "@/services/errorMessage";
import getDateIntervalApiParameters from "@/utils/dateIntervalApiParameters";

@Component
export default class BalanceEvolution extends Vue {
  @Prop({ default: () => [] }) dateInterval!: string[];
  @Prop({ default: null }) scopeUserId!: number | null;
  balanceEvolutionLoading = false;

  chartData = {
    options: {
      chart: {
        id: "balance-evolution",
        toolbar: {
          show: false,
        },
      },
      xaxis: {
        type: "datetime",
        categories: [] as string[],
      },
      stroke: {
        curve: "smooth",
        width: 3,
      },
      colors: ["#38a3a5"],
      fill: {
        type: "gradient",
        gradient: {
          shadeIntensity: 1,
          opacityFrom: 0.7,
          opacityTo: 0.2,
          stops: [0, 90, 100],
        },
      },
      dataLabels: {
        enabled: false,
      },
      tooltip: {
        x: {
          format: "dd MMM yyyy",
        },
      },
    },
    series: [
      {
        name: "余额",
        data: [] as TimeSeriesEntry[],
      },
    ],
  };

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    this.getBalanceEvolution();
  }

  getBalanceEvolution() {
    this.balanceEvolutionLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.balanceEvolutionLoading = false;
      return;
    }

    const parameters = getDateIntervalApiParameters(this.dateInterval);
    if (this.scopeUserId !== null) {
      parameters.push({ name: "scope_user_id", value: this.scopeUserId });
    }

    userApi
      .getBalanceEvolution(this.familyId, parameters)
      .then((response) => (this.chartData.series[0].data = response.data))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.balanceEvolutionLoading = false));
  }

  @Watch("dateInterval")
  onDateIntervalChange(): void {
    if (this.dateInterval.length === 2) {
      this.getBalanceEvolution();
    }
  }

  @Watch("scopeUserId")
  onScopeUserIdChange(): void {
    this.getBalanceEvolution();
  }
}
</script>

<style scoped>
.container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 1rem 0;
}

.chart-wrapper {
  width: 100%;
  flex: 1;
  padding: 0 1rem 1rem 1rem;
  overflow: hidden;
}

h2 {
  text-align: center;
  padding: 1rem 0;
  font-size: 1.5rem;
}

.skeleton {
  width: 100%;
  height: 350px;
}

@media only screen and (max-width: 550px) {
  h2 {
    text-align: start;
    padding-left: 1rem;
  }

  .chart-wrapper {
    padding: 0 0.5rem 0.5rem 0.5rem;
  }
}
</style>

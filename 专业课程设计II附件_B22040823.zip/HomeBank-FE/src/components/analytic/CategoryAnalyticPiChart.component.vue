<template>
  <div class="container">
    <h2 v-if="!categoryAnalyticLoading" class="main primary--text">分类</h2>

    <div
      class="no-records"
      v-if="!categoryAnalyticLoading && categoryAnalytics.length === 0"
    >
      {{ formattedDateInterval }} 期间没有记录
    </div>

    <div class="chart-wrapper">
      <apex-chart
        v-if="!categoryAnalyticLoading && categoryAnalytics.length > 0"
        type="donut"
        width="100%"
        height="320"
        :options="piChartData.options"
        :series="piChartData.series"
        class="pi-chart"
      />
    </div>

    <v-skeleton-loader
      v-if="categoryAnalyticLoading"
      type="image"
      class="skeleton"
    />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import { Action, Getter } from "vuex-class";
import categoryApi, { CategoryAnalytic } from "@/api/categoryApi";
import errorMessage from "@/services/errorMessage";
import { formatDate } from "@/utils/formatDate";
import getDateIntervalApiParameters from "@/utils/dateIntervalApiParameters";

@Component
export default class CategoryAnalyticPiChart extends Vue {
  @Prop({ default: () => [] }) dateInterval!: string[];
  @Prop({ default: null }) scopeUserId!: number | null;
  @Prop({ default: 500 }) width!: number;
  @Prop({ default: 286 }) height!: number;
  categoryAnalytics = [] as CategoryAnalytic[];
  categoryAnalyticLoading = false;
  piChartData = {
    options: {
      labels: [] as string[],
      colors: [] as string[],
      responsive: [
        {
          breakpoint: 600,
          options: {
            chart: {
              width: 300,
              height: 400,
            },
            legend: {
              position: "bottom",
              width: 300,
            },
          },
        },
        {
          breakpoint: 400,
          options: {
            chart: {
              width: 250,
              height: 400,
            },
            legend: {
              position: "bottom",
              width: 250,
            },
          },
        },
      ],
    },
    series: [] as number[],
  };

  get formattedDateInterval() {
    return (
      formatDate(this.dateInterval[0]) +
      " - " +
      formatDate(this.dateInterval[1])
    );
  }

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    this.getPiChartData();
  }

  getPiChartData() {
    this.categoryAnalyticLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.categoryAnalyticLoading = false;
      return;
    }

    const parameters = getDateIntervalApiParameters(this.dateInterval);
    if (this.scopeUserId !== null) {
      parameters.push({ name: "scope_user_id", value: this.scopeUserId });
    }

    categoryApi
      .getAnalytic(this.familyId, parameters)
      .then((response) => {
        this.categoryAnalytics = response.data;
        this.piChartData.options.labels = this.categoryAnalytics.map(
          (c: CategoryAnalytic) => c.category.name
        );
        this.piChartData.series = this.categoryAnalytics.map(
          (c: CategoryAnalytic) => c.amount
        );
        this.piChartData.options.colors = this.categoryAnalytics.map(
          (c: CategoryAnalytic) => c.category.color
        );
      })
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.categoryAnalyticLoading = false));
  }

  @Watch("dateInterval")
  onDateIntervalChange(): void {
    if (this.dateInterval.length === 2) {
      this.getPiChartData();
    }
  }

  @Watch("scopeUserId")
  onScopeUserIdChange(): void {
    this.getPiChartData();
  }
}
</script>

<style scoped>
.container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 1rem 0;
}

.chart-wrapper {
  width: 100%;
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
}

.pi-chart {
  width: 100%;
}

h2 {
  text-align: center;
  padding: 1rem 0;
  font-size: 1.5rem;
}

.skeleton {
  width: 100%;
  height: 320px;
}

.no-records {
  height: 320px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #666;
  font-size: 1.1rem;
}

@media only screen and (max-width: 550px) {
  h2 {
    text-align: start;
    padding-left: 1rem;
  }

  .chart-wrapper {
    padding: 0 0.5rem;
  }
}
</style>

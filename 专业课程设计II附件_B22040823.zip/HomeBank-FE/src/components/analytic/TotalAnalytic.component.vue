<template>
  <div class="container">
    <h2
      v-if="!totalAnalyticLoading && totalAnalytic"
      class="main primary--text"
    >
      支出统计
    </h2>
    <div v-if="!totalAnalyticLoading && totalAnalytic" class="rows">
      <div class="row">
        <h3>总余额：</h3>
        <span>
          <span class="value">
            {{ totalAnalytic.balance.toFixed(2) }}
          </span>
          {{ totalAnalytic.currency }}
        </span>
      </div>

      <div class="row">
        <h3>总收入：</h3>
        <span>
          <span class="value green--text">
            {{ totalAnalytic.incomes.toFixed(2) }}
          </span>
          {{ totalAnalytic.currency }}
        </span>
      </div>

      <div class="row">
        <h3>总支出：</h3>
        <span>
          <span class="value red--text">
            {{ totalAnalytic.expenses.toFixed(2) }}
          </span>
          {{ totalAnalytic.currency }}
        </span>
      </div>

      <div class="row">
        <h3>总现金流：</h3>
        <span>
          <span
            class="value"
            :class="totalAnalytic.cashFlow < 0 ? 'red--text' : 'green--text'"
            >{{ totalAnalytic.cashFlow.toFixed(2) }}</span
          >
          {{ totalAnalytic.currency }}
        </span>
      </div>
    </div>
    <div
      v-else-if="!totalAnalyticLoading && !totalAnalytic"
      class="bigger-text"
    >
      分析功能暂未实现
    </div>
    <v-skeleton-loader v-else type="image" class="skeleton" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import userApi, { TotalAnalytic } from "@/api/userApi";
import { Action, Getter } from "vuex-class";
import errorMessage from "@/services/errorMessage";
import getDateIntervalApiParameters from "@/utils/dateIntervalApiParameters";

@Component
export default class TotalAnalyticComponent extends Vue {
  @Prop({ default: () => [] }) dateInterval!: string[];
  @Prop({ default: null }) scopeUserId!: number | null;

  totalAnalyticLoading = false;
  totalAnalytic = null as null | TotalAnalytic;

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    this.getTotalAnalytic();
  }

  getTotalAnalytic() {
    this.totalAnalyticLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.totalAnalyticLoading = false;
      return;
    }

    const parameters = getDateIntervalApiParameters(this.dateInterval);
    if (this.scopeUserId !== null) {
      parameters.push({ name: "scope_user_id", value: this.scopeUserId });
    }

    userApi
      .getTotalAnalytic(this.familyId, parameters)
      .then((response) => (this.totalAnalytic = response.data))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.totalAnalyticLoading = false));
  }

  @Watch("dateInterval")
  onDateIntervalChange(): void {
    if (this.dateInterval.length === 2) {
      this.getTotalAnalytic();
    }
  }

  @Watch("scopeUserId")
  onScopeUserIdChange(): void {
    this.getTotalAnalytic();
  }
}
</script>

<style scoped>
.container {
  width: 100%;
  height: 100%;
}

.rows {
  padding: 0 2rem 2rem 2rem;
}

.row {
  margin-bottom: 1.25rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 1.25rem;
}

.skeleton {
  width: 100%;
  height: 100%;
}

h2 {
  text-align: center;
  padding: 1rem 0;
  font-size: 1.5rem;
}

h3 {
  display: inline;
  font-weight: normal;
  font-size: 1rem;
  margin-right: 0.5rem;
}

.value {
  font-weight: 500;
  font-size: 1.25rem;
}

@media only screen and (max-width: 550px) {
  .row {
    flex-direction: column;
    align-items: start;
  }

  h2 {
    text-align: start;
    padding-left: 1rem;
  }
}
</style>

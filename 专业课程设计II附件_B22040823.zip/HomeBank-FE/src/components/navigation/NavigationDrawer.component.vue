<template>
  <v-navigation-drawer v-model="drawerOpenLocal" app left temporary>
    <v-list nav dense>
      <v-list-item-group active-class="secondary--text text--accent-4">
        <v-list-item class="mb-4">
          <div v-if="loggedIn" class="mt-2 d-flex align-start flex-column">
            <div>
              <v-avatar color="primary" size="40">
                <span class="white--text">{{
                  (user.firstName[0] + user.lastName[0]).toLocaleUpperCase()
                }}</span>
              </v-avatar>
              <span class="mx-2">
                {{ user.firstName + " " + user.lastName }}
              </span>
            </div>
            <v-btn icon plain router to="/" @click="logOut()" class="ml-8 mt-2">
              退出登录
              <v-icon right>mdi-exit-to-app</v-icon>
            </v-btn>
          </div>

          <div v-else class="d-flex">
            <v-btn color="secondary" router to="/register">
              <v-icon left>mdi-account-plus-outline</v-icon>注册
            </v-btn>
            <v-btn plain class="ml-1" router to="/login">
              <v-icon left>mdi-account-lock-open-outline</v-icon>登录
            </v-btn>
          </div>
        </v-list-item>

        <v-divider />

        <div v-if="loggedIn">
          <v-list-item
            v-for="(link, index) in links"
            :key="index"
            link
            :to="link.to"
          >
            <v-list-item-icon>
              <v-badge
                v-if="link.to === '/alerts'"
                :content="unreadCount"
                :value="unreadCount > 0"
                color="red"
                overlap
              >
                <v-icon>{{ link.icon }}</v-icon>
              </v-badge>
              <v-icon v-else>{{ link.icon }}</v-icon>
              <v-list-item-content>
                <v-list-item-title>
                  {{ link.label }}
                </v-list-item-title>
              </v-list-item-content>
            </v-list-item-icon>
          </v-list-item>
        </div>

        <div v-else>
          <a
            v-for="(link, index) in links"
            :key="index"
            :href="link.to"
            class="drawer-link"
          >
            <v-list-item>
              <v-list-item-icon>
                <v-icon>{{ link.icon }}</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title>
                  {{ link.label }}
                </v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </a>
        </div>
      </v-list-item-group>
    </v-list>
  </v-navigation-drawer>
</template>

<script lang="ts">
import { Component, Vue, Prop, PropSync } from "vue-property-decorator";
import { NavigationLink } from "./Navbar.component.vue";
import { Getter, Mutation } from "vuex-class";
import { User } from "@/store/modules/user";

@Component
export default class NavigationDrawer extends Vue {
  @PropSync("drawerOpen", { default: false }) drawerOpenLocal!: boolean;
  @Prop() links: NavigationLink[] | undefined;

  @Getter("user/loggedIn") loggedIn!: boolean;
  @Getter("user/user") user!: User | null;
  @Getter("alert/unreadCount") unreadCount!: number;

  @Mutation("user/logOut") logOut!: () => void;

  mounted(): void {
    if (this.loggedIn) {
      this.$store.dispatch("alert/fetchUnreadCount");
      this.$store.dispatch("alert/startPolling");
    }
  }

  beforeDestroy(): void {
    this.$store.dispatch("alert/stopPolling");
  }
}
</script>

<style scoped>
.drawer-link {
  text-decoration: none;
}
</style>

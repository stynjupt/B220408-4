<template>
  <div>
    <v-app-bar app color="primary" dark class="ma0">
      <div class="d-flex align-center justify-space-between max-width">
        <div class="d-flex align-center justify-center">
          <Logo class="logo" />
          <v-toolbar-title>HomeBank</v-toolbar-title>
        </div>

        <NavbarDesktopLinks :links="links" />

        <v-app-bar-nav-icon
          @click="drawerOpen = true"
          class="d-flex d-md-none"
        />
      </div>
    </v-app-bar>

    <NavigationDrawer :links="links" :drawerOpen.sync="drawerOpen" />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import Logo from "../Logo.component.vue";
import NavigationDrawer from "./NavigationDrawer.component.vue";
import NavbarDesktopLinks from "./NavbarDesktopLinks.component.vue";
import { Getter } from "vuex-class";

interface NavigationLink {
  to: string;
  label: string;
  icon: string;
  adminOnly?: boolean;
}

@Component({
  components: {
    Logo,
    NavigationDrawer,
    NavbarDesktopLinks,
  },
})
export default class Navbar extends Vue {
  drawerOpen = false;

  @Getter("user/loggedIn") loggedIn!: boolean;
  @Getter("user/isFamilyAdmin") isFamilyAdmin!: boolean;

  homeLinks = [
    {
      to: "/#start",
      label: "首页",
      icon: "mdi-home-outline",
    },
    {
      to: "/#about",
      label: "关于",
      icon: "mdi-information-outline",
    },
    {
      to: "/#contact",
      label: "联系",
      icon: "mdi-email-outline",
    },
  ] as NavigationLink[];

  appLinks = [
    {
      to: "/dashboard",
      label: "仪表板",
      icon: "mdi-view-dashboard-outline",
    },
    {
      to: "/records",
      label: "记录",
      icon: "mdi-view-list-outline",
    },
    {
      to: "/analytic",
      label: "分析",
      icon: "mdi-finance",
    },
    {
      to: "/family",
      label: "家庭",
      icon: "mdi-home-group",
      adminOnly: true,
    },
    {
      to: "/budgets",
      label: "预算",
      icon: "mdi-wallet",
      adminOnly: true,
    },
    {
      to: "/alerts",
      label: "提醒",
      icon: "mdi-bell",
    },
  ] as NavigationLink[];

  get links(): NavigationLink[] {
    if (!this.loggedIn) return this.homeLinks;

    return this.appLinks.filter((link) => {
      if (link.adminOnly) {
        return this.isFamilyAdmin;
      }
      return true;
    });
  }
}

export { NavigationLink };
</script>

<style scoped>
.logo {
  height: 2rem;
  width: 2rem;
  margin-right: 1rem;
}
</style>

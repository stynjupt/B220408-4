<template>
  <v-card class="mb-3">
    <v-card-text>
      <v-row align="center">
        <v-col cols="auto">
          <v-avatar
            :color="member.role === 'FAMILY_ADMIN' ? 'primary' : 'grey'"
            size="48"
          >
            <v-icon dark>mdi-account</v-icon>
          </v-avatar>
        </v-col>
        <v-col>
          <div class="text-h6">
            {{ member.firstName }} {{ member.lastName }}
          </div>
          <div class="text-caption text--secondary">
            {{ member.email }}
          </div>
        </v-col>
        <v-col cols="auto">
          <v-chip
            small
            :color="member.role === 'FAMILY_ADMIN' ? 'primary' : 'grey'"
            text-color="white"
          >
            {{ roleText }}
          </v-chip>
        </v-col>
        <v-col cols="auto" v-if="canRemove">
          <v-btn icon small color="red" @click="$emit('remove', member.id)">
            <v-icon small>mdi-account-remove</v-icon>
          </v-btn>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { User } from "@/api/familyApi";

@Component
export default class FamilyMemberCard extends Vue {
  @Prop({ required: true }) member!: User;
  @Prop({ default: false }) canRemove!: boolean;

  get roleText(): string {
    return this.member.role === "FAMILY_ADMIN" ? "家庭管理员" : "家庭成员";
  }
}
</script>

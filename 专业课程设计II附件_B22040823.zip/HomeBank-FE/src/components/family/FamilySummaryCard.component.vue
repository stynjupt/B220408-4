<template>
  <v-card>
    <v-card-title>
      <v-icon left color="primary">mdi-home-group</v-icon>
      家庭财务概览
    </v-card-title>
    <v-card-text>
      <v-row>
        <v-col cols="12" sm="6">
          <div class="text-caption text--secondary">总收入</div>
          <div class="text-h5 green--text">
            {{ formatCurrency(summary.totalIncome) }}
          </div>
        </v-col>
        <v-col cols="12" sm="6">
          <div class="text-caption text--secondary">总支出</div>
          <div class="text-h5 red--text">
            {{ formatCurrency(summary.totalExpense) }}
          </div>
        </v-col>
        <v-col cols="12" sm="6">
          <div class="text-caption text--secondary">净额</div>
          <div class="text-h5" :class="netAmountColor">
            {{ formatCurrency(netAmount) }}
          </div>
        </v-col>
        <v-col cols="12" sm="6">
          <div class="text-caption text--secondary">家庭成员</div>
          <div class="text-h5">{{ summary.memberCount }} 人</div>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { FamilySummary } from "@/api/familyApi";

@Component
export default class FamilySummaryCard extends Vue {
  @Prop({ required: true }) summary!: FamilySummary;

  get netAmount(): number {
    return this.summary.totalIncome - this.summary.totalExpense;
  }

  get netAmountColor(): string {
    return this.netAmount >= 0 ? "green--text" : "red--text";
  }

  formatCurrency(amount: number): string {
    const currency = this.$store.getters["user/currency"] || "CNY";
    return new Intl.NumberFormat("zh-CN", {
      style: "currency",
      currency: currency,
    }).format(amount);
  }
}
</script>

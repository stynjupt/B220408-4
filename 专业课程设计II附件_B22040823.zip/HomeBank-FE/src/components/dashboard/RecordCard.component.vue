<template>
  <v-card
    class="elevation-2 records px-6 py-2"
    @click="
      $router.push({ name: 'UpdateRecord', params: { recordId: record.id } })
    "
  >
    <div class="row">
      <div>
        <span class="record-name mr-4 font-weight-bold">
          {{ record.label }}
        </span>

        <span class="note">{{ record.note }}</span>
      </div>

      <div class="date-section">
        <span class="creator-name"> @{{ creatorName }} </span>

        <span class="record-date">
          {{ formattedDateAndTime }}
        </span>
      </div>
    </div>

    <span class="note-mobile">{{ record.note }}</span>

    <div class="row row2">
      <div>
        <ChipWithIcon
          v-if="record.category"
          :config="record.category"
          class="mr-4"
        />

        <ChipWithIcon v-if="record.account" :config="record.account" />
      </div>

      <span
        class="amount"
        :class="record.type === 'EXPENSE' ? 'red--text' : 'green--text'"
      >
        {{ record.type === "EXPENSE" ? "-" : "+"
        }}{{ record.amount.toFixed(2) }}
        <span v-if="record.account">{{ record.account.currency }}</span>
      </span>
    </div>
  </v-card>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { Record } from "@/api/recordApi";
import ChipWithIcon from "@/components/ChipWithIcon.component.vue";
import { formatDate } from "@/utils/formatDate";

@Component({
  components: { ChipWithIcon },
})
export default class RecordCard extends Vue {
  @Prop({ required: true }) readonly record!: Record;

  get formattedDateAndTime(): string {
    return formatDate(this.record.date);
  }

  get creatorName(): string {
    return `${this.record.userFirstName} ${this.record.userLastName}`;
  }
}
</script>

<style scoped>
.row {
  display: flex;
  justify-content: space-between;
  margin: 0.5rem 0;
}

.date-section {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.creator-name {
  color: grey;
}

.note-mobile {
  display: none;
}

.amount {
  font-weight: bold;
}

@media only screen and (max-width: 750px) {
  .note {
    display: none;
  }

  .note-mobile {
    display: inline-flex;
  }
}

@media only screen and (max-width: 500px) {
  .row2 {
    flex-direction: column;
  }

  .amount {
    margin-top: 0.5rem;
  }
}
</style>

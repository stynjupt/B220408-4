<template>
  <section>
    <div class="heading-and-button mb-6">
      <h2 class="main primary--text">最近记录</h2>

      <v-btn
        color="secondary"
        @click="$router.push('/records/create')"
        elevation="4"
      >
        <v-icon left>mdi-plus</v-icon>
        <span>添加记录</span>
      </v-btn>
    </div>

    <div>
      <div v-if="records.length > 0 || recordsLoading">
        <div v-if="!recordsLoading">
          <RecordCard
            v-for="record in records"
            :key="`record${record.id}`"
            :record="record"
            class="mb-4"
          />
        </div>

        <div v-else>
          <v-skeleton-loader
            v-for="i in 5"
            :key="'record-loader' + i"
            type="image"
            class="skeleton"
          />
        </div>

        <div class="more-records">
          <router-link to="/records" class="">更多记录</router-link>
        </div>
      </div>

      <div v-else class="bigger-text">您还没有创建任何记录！</div>
    </div>
  </section>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Action, Getter } from "vuex-class";
import recordApi, { Record } from "@/api/recordApi";
import errorMessage from "@/services/errorMessage";
import RecordCard from "@/components/dashboard/RecordCard.component.vue";

@Component({
  components: { RecordCard },
})
export default class RecordsSection extends Vue {
  records = [] as Record[];
  recordsLoading = false;

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;
  @Getter("user/familyId") familyId!: number | null;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      return;
    }

    this.recordsLoading = true;
    recordApi
      .getAll(this.familyId, 0, 20, [{ name: "sort", value: "date,desc" }])
      .then((response) => (this.records = response.data.content))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.recordsLoading = false));
  }
}
</script>

<style scoped>
.skeleton {
  height: 5.5rem;
  margin-bottom: 1rem;
}

.more-records {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 2rem auto;
}

.more-records a {
  color: #38a3a5;
  font-weight: 600;
  font-size: 1.1rem;
  text-decoration: none;
  padding: 0.75rem 2rem;
  border: 2px solid #38a3a5;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.more-records a:hover {
  background: #38a3a5;
  color: white;
}
</style>

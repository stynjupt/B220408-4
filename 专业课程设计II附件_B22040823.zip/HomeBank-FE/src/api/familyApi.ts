import API from "./api";
import { AxiosResponse as Response } from "axios";

interface Family {
  id: number;
  name: string;
  currency: string;
  createdAt: string;
}

interface User {
  id: number;
  familyId: number;
  email: string;
  firstName: string;
  lastName: string;
  currency: string;
  role: "FAMILY_ADMIN" | "FAMILY_MEMBER";
  isActive: boolean;
  createdAt: string;
  accountIds: number[];
}

interface AddFamilyMemberRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: "FAMILY_ADMIN" | "FAMILY_MEMBER";
}

interface FamilySummary {
  familyId: number;
  familyName: string;
  totalIncome: number;
  totalExpense: number;
  memberCount: number;
  dateInterval: {
    start: string;
    end: string;
  };
}

const FamilyApi = {
  API: API.getInstance(),
  DOMAIN: "/families",

  getById(id: number): Promise<Response<Family>> {
    return this.API.get(`${this.DOMAIN}/${id}`);
  },

  update(id: number, data: Partial<Family>): Promise<Response<Family>> {
    return this.API.put(`${this.DOMAIN}/${id}`, data);
  },

  getMembers(familyId: number): Promise<Response<User[]>> {
    return this.API.get(`${this.DOMAIN}/${familyId}/members`);
  },

  addMember(
    familyId: number,
    data: AddFamilyMemberRequest
  ): Promise<Response<User>> {
    return this.API.post(`${this.DOMAIN}/${familyId}/members`, data);
  },

  removeMember(familyId: number, userId: number): Promise<Response> {
    return this.API.delete(`${this.DOMAIN}/${familyId}/members/${userId}`);
  },
};

export default FamilyApi;
export { FamilyApi, Family, User, AddFamilyMemberRequest, FamilySummary };

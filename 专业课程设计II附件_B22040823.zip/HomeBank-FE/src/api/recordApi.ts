import { AxiosResponse as Response } from "axios";
import API, { PaginatedResponse } from "@/api/api";
import { ApiParameter } from "@/api/api";
import { Category } from "@/api/categoryApi";
import { AccountReduced } from "@/api/accountApi";

interface Record {
  id: number;
  userId: number;
  userFirstName: string;
  userLastName: string;
  userEmail: string;
  amount: number;
  label: string;
  note: string;
  date: string;
  account: AccountReduced;
  category: Category;
  type: "INCOME" | "EXPENSE";
  createdAt: string;
  updatedAt: string;
}

interface CreateUpdateRecordRequest {
  amount: number;
  label: string;
  note: string;
  date: string;
  accountId?: number;
  categoryId?: number;
  type?: "INCOME" | "EXPENSE";
}

const RecordApi = {
  API: API.getInstance(),

  getAll(
    familyId: number,
    page = 0,
    size = 200,
    parameters = [] as ApiParameter[]
  ): Promise<Response<PaginatedResponse<Record>>> {
    parameters.push({ name: "page", value: page });
    parameters.push({ name: "size", value: size });
    return this.API.get(`/families/${familyId}/records`, parameters);
  },

  getById(familyId: number, recordId: number): Promise<Response<Record>> {
    return this.API.get(`/families/${familyId}/records/${recordId}`);
  },

  createRecord(
    familyId: number,
    record: CreateUpdateRecordRequest
  ): Promise<Response<Record>> {
    return this.API.post(`/families/${familyId}/records`, record);
  },

  updateRecord(
    familyId: number,
    recordId: number,
    record: CreateUpdateRecordRequest
  ): Promise<Response<Record>> {
    return this.API.put(`/families/${familyId}/records/${recordId}`, record);
  },

  deleteRecord(familyId: number, recordId: number): Promise<Response> {
    return this.API.delete(`/families/${familyId}/records/${recordId}`);
  },

  recordToCreateUpdateRecordRequest(record: Record): CreateUpdateRecordRequest {
    return {
      amount: record.type === "INCOME" ? record.amount : -record.amount,
      label: record.label,
      note: record.note,
      date: record.date,
      accountId: record.account.id,
      categoryId: record.category.id,
      type: record.type,
    };
  },
};

export default RecordApi;
export { RecordApi, Record, CreateUpdateRecordRequest };

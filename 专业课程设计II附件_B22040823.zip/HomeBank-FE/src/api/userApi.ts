import API, { ApiParameter } from "@/api/api";
import { AxiosResponse as Response } from "axios/index";

interface TotalAnalytic {
  incomes: number;
  expenses: number;
  cashFlow: number;
  balance: number;
  currency: string;
}

interface TimeSeriesEntry {
  y: number;
  x: Date;
}

const userApi = {
  API: API.getInstance(),

  getTotalAnalytic(
    familyId: number,
    parameters = [] as ApiParameter[]
  ): Promise<Response<TotalAnalytic>> {
    return this.API.get(`/families/${familyId}/analytics/total`, parameters);
  },

  getBalanceEvolution(
    familyId: number,
    parameters = [] as ApiParameter[]
  ): Promise<Response<TimeSeriesEntry[]>> {
    return this.API.get(
      `/families/${familyId}/analytics/balance-evolution`,
      parameters
    );
  },
};

export default userApi;
export { userApi, TotalAnalytic, TimeSeriesEntry };

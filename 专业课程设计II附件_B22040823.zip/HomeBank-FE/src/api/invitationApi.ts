import API from "./api";
import { AxiosResponse as Response } from "axios";

type InvitationStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "EXPIRED";

interface FamilyInvitation {
  id: number;
  familyId: number;
  familyName: string;
  inviteeEmail: string;
  role: "FAMILY_ADMIN" | "FAMILY_MEMBER";
  token: string;
  status: InvitationStatus;
  expiresAt: string;
  createdAt: string;
}

interface CreateInvitationRequest {
  inviteeEmail: string;
  role?: "FAMILY_ADMIN" | "FAMILY_MEMBER";
}

const InvitationApi = {
  API: API.getInstance(),

  createInvitation(
    familyId: number,
    request: CreateInvitationRequest
  ): Promise<Response<FamilyInvitation>> {
    return this.API.post(`/families/${familyId}/invitations`, request);
  },

  getFamilyInvitations(
    familyId: number
  ): Promise<Response<FamilyInvitation[]>> {
    return this.API.get(`/families/${familyId}/invitations`);
  },

  getMyInvitations(): Promise<Response<FamilyInvitation[]>> {
    return this.API.get(`/families/0/invitations/me`);
  },

  acceptInvitation(
    familyId: number,
    token: string
  ): Promise<Response<FamilyInvitation>> {
    return this.API.post(
      `/families/${familyId}/invitations/${token}/accept`,
      {}
    );
  },

  rejectInvitation(familyId: number, token: string): Promise<Response<void>> {
    return this.API.post(
      `/families/${familyId}/invitations/${token}/reject`,
      {}
    );
  },

  cancelInvitation(
    familyId: number,
    invitationId: number
  ): Promise<Response<void>> {
    return this.API.delete(`/families/${familyId}/invitations/${invitationId}`);
  },
};

export default InvitationApi;
export { FamilyInvitation, CreateInvitationRequest, InvitationStatus };

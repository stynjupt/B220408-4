import API, { ApiParameter } from "./api";
import { AxiosResponse as Response } from "axios";

interface Budget {
  id: number;
  familyId: number;
  categoryId: number;
  categoryName: string;
  amount: number;
  period: "MONTHLY" | "QUARTERLY" | "YEARLY";
  startDate: string;
  endDate: string;
  createdById: number;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
}

interface CreateBudgetRequest {
  categoryId: number;
  amount: number;
  period: "MONTHLY" | "QUARTERLY" | "YEARLY";
  startDate: string;
  endDate?: string;
}

interface BudgetStatus {
  budgetId: number;
  categoryName: string;
  budgetAmount: number;
  spentAmount: number;
  remainingAmount: number;
  usagePercentage: number;
  isWarning: boolean;
  isExceeded: boolean;
}

const BudgetApi = {
  API: API.getInstance(),

  getAll(
    familyId: number,
    parameters: ApiParameter[] = []
  ): Promise<Response<Budget[]>> {
    return this.API.get(`/families/${familyId}/budgets`, parameters);
  },

  getById(familyId: number, budgetId: number): Promise<Response<Budget>> {
    return this.API.get(`/families/${familyId}/budgets/${budgetId}`);
  },

  getBudgetStatus(
    familyId: number,
    budgetId: number
  ): Promise<Response<BudgetStatus>> {
    return this.API.get(`/families/${familyId}/budgets/${budgetId}/status`);
  },

  create(
    familyId: number,
    data: CreateBudgetRequest
  ): Promise<Response<Budget>> {
    return this.API.post(`/families/${familyId}/budgets`, data);
  },

  update(
    familyId: number,
    budgetId: number,
    data: Partial<CreateBudgetRequest>
  ): Promise<Response<Budget>> {
    return this.API.put(`/families/${familyId}/budgets/${budgetId}`, data);
  },

  delete(familyId: number, budgetId: number): Promise<Response> {
    return this.API.delete(`/families/${familyId}/budgets/${budgetId}`);
  },
};

export default BudgetApi;
export { BudgetApi, Budget, CreateBudgetRequest, BudgetStatus };

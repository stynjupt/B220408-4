interface FamilyMembership {
  familyId: number;
  familyName: string;
  role: "FAMILY_ADMIN" | "FAMILY_MEMBER";
  isActive: boolean;
}

interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  currency: string;

  memberships: FamilyMembership[];

  familyId: number;

  role: "FAMILY_ADMIN" | "FAMILY_MEMBER";

  accountIds: number[];
}

class State {
  user = null as null | User;
  token = null as string | null;
  userLocalStorageKey = "user";
  tokenLocalStorageKey = "token";
  expirationStorageKey = "expiration";
}

const user = {
  namespaced: true,
  state: new State(),
  mutations: {
    setTokenAndUser: (
      state: State,
      { token, user }: { token: string; user: User }
    ): void => {
      state.user = user;
      state.token = token;
      const expiration = new Date();
      expiration.setDate(expiration.getDate() + 1);
      sessionStorage.setItem(
        state.expirationStorageKey,
        expiration.toISOString()
      );
      sessionStorage.setItem(state.tokenLocalStorageKey, state.token);
      sessionStorage.setItem(
        state.userLocalStorageKey,
        JSON.stringify(state.user)
      );
    },

    logOut: (state: State): void => {
      state.user = null;
      state.token = null;
      sessionStorage.removeItem(state.tokenLocalStorageKey);
      sessionStorage.removeItem(state.userLocalStorageKey);
    },

    loadFromLocalStorage(state: State): void {
      const expiration = sessionStorage.getItem(state.expirationStorageKey);
      const token = sessionStorage.getItem(state.tokenLocalStorageKey);
      const user = sessionStorage.getItem(state.userLocalStorageKey);
      if (!expiration || !token || !user) {
        return;
      }
      if (new Date().getTime() > new Date(expiration).getTime()) {
        state.user = null;
        state.token = null;
        sessionStorage.removeItem(state.tokenLocalStorageKey);
        sessionStorage.removeItem(state.userLocalStorageKey);
        return;
      }
      state.user = JSON.parse(user) as User;
      state.token = token;
    },
  },
  getters: {
    user: (state: State): User | null => {
      return state.user;
    },

    loggedIn: (state: State): boolean => {
      return state.user != null && state.token != null;
    },
    token: (state: State): string | null => {
      return state.token;
    },
    currency: (state: State): string | undefined => {
      return state.user?.currency;
    },

    isFamilyAdmin: (state: State): boolean => {
      return state.user?.role === "FAMILY_ADMIN";
    },

    familyId: (state: State): number | null => {
      return state.user?.familyId || null;
    },

    memberships: (state: State): FamilyMembership[] => {
      return state.user?.memberships || [];
    },

    getRoleInFamily:
      (state: State) =>
      (familyId: number): string | null => {
        if (!state.user) return null;
        const membership = state.user.memberships.find(
          (m) => m.familyId === familyId && m.isActive
        );
        return membership?.role || null;
      },

    isAdminInFamily:
      (state: State) =>
      (familyId: number): boolean => {
        if (!state.user) return false;
        const membership = state.user.memberships.find(
          (m) => m.familyId === familyId && m.isActive
        );
        return membership?.role === "FAMILY_ADMIN";
      },
  },
  actions: {},
};

export default user;
export { User, FamilyMembership };

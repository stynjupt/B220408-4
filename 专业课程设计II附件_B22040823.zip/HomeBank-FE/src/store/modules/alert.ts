import { Alert } from "@/api/alertApi";
import { ActionContext } from "vuex";

class State {
  alerts = [] as Alert[];
  unreadCount = 0;
  drawerOpen = false;
  polling = false;
  pollingInterval = null as null | number;
}

type AlertContext = ActionContext<State, unknown>;

const alert = {
  namespaced: true,
  state: new State(),
  mutations: {
    setAlerts(state: State, alerts: Alert[]): void {
      state.alerts = alerts;
    },
    setUnreadCount(state: State, count: number): void {
      state.unreadCount = count;
    },
    markAsRead(state: State, alertId: number): void {
      const alert = state.alerts.find((a) => a.id === alertId);
      if (alert) {
        alert.isRead = true;
        state.unreadCount = Math.max(0, state.unreadCount - 1);
      }
    },
    toggleDrawer(state: State): void {
      state.drawerOpen = !state.drawerOpen;
    },
    setDrawerOpen(state: State, open: boolean): void {
      state.drawerOpen = open;
    },
    setPolling(state: State, polling: boolean): void {
      state.polling = polling;
    },
    setPollingInterval(state: State, interval: number | null): void {
      state.pollingInterval = interval;
    },
    removeAlert(state: State, alertId: number): void {
      const alert = state.alerts.find((a) => a.id === alertId);
      if (alert && !alert.isRead) {
        state.unreadCount = Math.max(0, state.unreadCount - 1);
      }
      state.alerts = state.alerts.filter((a) => a.id !== alertId);
    },
  },
  getters: {
    alerts: (state: State): Alert[] => {
      return state.alerts;
    },
    unreadCount: (state: State): number => {
      return state.unreadCount;
    },
    drawerOpen: (state: State): boolean => {
      return state.drawerOpen;
    },
    unreadAlerts: (state: State): Alert[] => {
      return state.alerts.filter((a) => !a.isRead);
    },
  },
  actions: {
    async fetchAlerts({ commit }: AlertContext): Promise<void> {
      try {
        const AlertApi = (await import("@/api/alertApi")).default;
        const response = await AlertApi.getAll();
        commit("setAlerts", response.data);
        const unreadCount = response.data.filter(
          (a: Alert) => !a.isRead
        ).length;
        commit("setUnreadCount", unreadCount);
      } catch (error) {
        console.error("Failed to fetch alerts:", error);
      }
    },
    async fetchUnreadCount({ commit }: AlertContext): Promise<void> {
      try {
        const AlertApi = (await import("@/api/alertApi")).default;
        const response = await AlertApi.getUnread();
        commit("setUnreadCount", response.data.length);
      } catch (error) {
        console.error("Failed to fetch unread count:", error);
      }
    },
    async markAlertAsRead(
      { commit }: AlertContext,
      alertId: number
    ): Promise<void> {
      try {
        const AlertApi = (await import("@/api/alertApi")).default;
        await AlertApi.markAsRead(alertId);
        commit("markAsRead", alertId);
      } catch (error) {
        console.error("Failed to mark alert as read:", error);
        throw error;
      }
    },
    async deleteAlert(
      { commit }: AlertContext,
      alertId: number
    ): Promise<void> {
      try {
        const AlertApi = (await import("@/api/alertApi")).default;
        await AlertApi.delete(alertId);
        commit("removeAlert", alertId);
      } catch (error) {
        console.error("Failed to delete alert:", error);
        throw error;
      }
    },
    startPolling({ dispatch, commit, state }: AlertContext): void {
      if (state.polling) return;

      commit("setPolling", true);
      const interval = window.setInterval(() => {
        dispatch("fetchUnreadCount");
      }, 5 * 60 * 1000);

      commit("setPollingInterval", interval);
    },
    stopPolling({ commit, state }: AlertContext): void {
      if (state.pollingInterval) {
        clearInterval(state.pollingInterval);
        commit("setPollingInterval", null);
      }
      commit("setPolling", false);
    },
  },
};

export default alert;

import { Family, User } from "@/api/familyApi";
import { ActionContext } from "vuex";

class State {
  familyInfo = null as null | Family;
  members = [] as User[];
  loadingMembers = false;
}

type FamilyContext = ActionContext<State, unknown>;

const family = {
  namespaced: true,
  state: new State(),
  mutations: {
    setFamilyInfo(state: State, family: Family): void {
      state.familyInfo = family;
    },
    setMembers(state: State, members: User[]): void {
      state.members = members;
    },
    addMember(state: State, member: User): void {
      state.members.push(member);
    },
    removeMember(state: State, userId: number): void {
      state.members = state.members.filter((m) => m.id !== userId);
    },
    setLoadingMembers(state: State, loading: boolean): void {
      state.loadingMembers = loading;
    },
  },
  getters: {
    familyInfo: (state: State): Family | null => {
      return state.familyInfo;
    },
    members: (state: State): User[] => {
      return state.members;
    },
    loadingMembers: (state: State): boolean => {
      return state.loadingMembers;
    },
  },
  actions: {
    async fetchFamilyInfo(
      { commit }: FamilyContext,
      familyId: number
    ): Promise<void> {
      try {
        const FamilyApi = (await import("@/api/familyApi")).default;
        const response = await FamilyApi.getById(familyId);
        commit("setFamilyInfo", response.data);
      } catch (error) {
        console.error("Failed to fetch family info:", error);
        throw error;
      }
    },
    async fetchFamilyMembers(
      { commit }: FamilyContext,
      familyId: number
    ): Promise<void> {
      commit("setLoadingMembers", true);
      try {
        const FamilyApi = (await import("@/api/familyApi")).default;
        const response = await FamilyApi.getMembers(familyId);
        commit("setMembers", response.data);
      } catch (error) {
        console.error("Failed to fetch family members:", error);
        throw error;
      } finally {
        commit("setLoadingMembers", false);
      }
    },
  },
};

export default family;

import moment from "moment";

function formatDate(date: string | null | undefined): string {
  if (!date) return "-";
  try {
    return moment(new Date(date)).format("D. M. YYYY");
  } catch (error) {
    console.error("日期格式化错误:", error);
    return "-";
  }
}

function formatDateAndTime(date: string | null | undefined): string {
  if (!date) return "-";
  try {
    return moment(new Date(date)).format("D. M. YYYY H:mm");
  } catch (error) {
    console.error("日期时间格式化错误:", error);
    return "-";
  }
}

function formatYYYYMMDD(date: Date): string {
  return moment(date).format("YYYY-MM-DD");
}

export { formatDate, formatDateAndTime, formatYYYYMMDD };

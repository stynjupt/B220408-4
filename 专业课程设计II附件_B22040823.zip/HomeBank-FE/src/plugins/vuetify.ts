import Vue from "vue";
import Vuetify from "vuetify/lib/framework";

Vue.use(Vuetify);

export default new Vuetify({
  theme: {
    themes: {
      light: {
        primary: "#22577a",
        secondary: "#38a3a5",
        accent: "#57cc99",
        success: "#80ed99",
        info: "#c7f9cc",
      },
    },
  },
});

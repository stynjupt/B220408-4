<template>
  <div class="max-width">
    <v-card class="form" justify="center">
      <v-form ref="form" @submit.prevent="submit">
        <v-card-text>
          <h1 class="formHeading">登录</h1>

          <v-text-field
            v-model="authenticateForm.email"
            :rules="[rules.required, rules.email]"
            label="邮箱"
            placeholder="zhangsan@example.com"
            prepend-icon="mdi-email-outline"
            required
          />

          <v-text-field
            v-model="authenticateForm.password"
            :rules="[rules.required]"
            :type="showPassword ? 'text' : 'password'"
            label="密码"
            prepend-icon="mdi-lock-outline"
            :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
            @click:append="showPassword = !showPassword"
            required
          />

          <span>还没有账号？</span>
          <router-link to="/register">立即注册</router-link>
        </v-card-text>

        <v-card-actions>
          <v-btn color="primary px-4" type="submit" :loading="formLoading">
            登录
            <v-icon right>mdi-lock-open-outline</v-icon>
          </v-btn>
        </v-card-actions>
      </v-form>
    </v-card>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { AuthenticationRequest } from "@/api/authenticationApi";
import authenticationApi from "@/api/authenticationApi";
import errorMessage from "@/services/errorMessage";
import { Mutation, Action } from "vuex-class";
import { User } from "@/store/modules/user";
import { Getter } from "vuex-class";

@Component
export default class LogIn extends Vue {
  authenticateForm: AuthenticationRequest = {
    email: "",
    password: "",
  };

  formLoading = false;
  showPassword = false;
  emailPattern =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  fieldRequiredErrorMsg = "此项为必填项";

  rules = {
    email: (value: string): boolean | string =>
      this.emailPattern.test(value) || "邮箱格式不正确",
    required: (value: string): boolean | string =>
      !!value || this.fieldRequiredErrorMsg,
  };

  @Getter("user/loggedIn") loggedIn!: boolean;

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;

  @Mutation("user/setTokenAndUser") setTokenAndUser!: ({
    token,
    user,
  }: {
    token: string;
    user: User;
  }) => void;

  beforeMount(): void {
    if (this.loggedIn) {
      this.$router.push("/dashboard");
    }
  }

  submit(): void {
    this.formLoading = true;

    if (!(this.$refs["form"] as any)?.validate()) {
      this.formLoading = false;
      return;
    }
    authenticationApi
      .login(this.authenticateForm)
      .then((response: any) => {
        this.setTokenAndUser({
          token: response.data.token,
          user: response.data.user,
        });
        this.$router.push("/dashboard");
      })
      .catch((error: any) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.formLoading = false));
  }
}
</script>

<style scoped>
.form {
  max-width: 40rem;
  padding: 1.5rem;
  margin: 4rem auto;
}

.formHeading {
  font-weight: normal;
  margin-bottom: 1rem;
}

@media only screen and (max-width: 500px) {
  .form {
    padding: 1rem;
  }
}
</style>

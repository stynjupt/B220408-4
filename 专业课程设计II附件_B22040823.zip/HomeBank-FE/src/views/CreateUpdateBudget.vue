<template>
  <section class="max-width main">
    <ConfirmationDialog
      :show.sync="showDialog"
      :label="`确定删除此预算吗？`"
      @confirm="deleteBudget"
    />

    <h1 class="main">
      {{ update ? "编辑预算" : "创建预算" }}
    </h1>

    <v-form class="mt-8" ref="form" @submit.prevent="submit">
      <div class="row">
        <AutocompleteWitchIcons
          v-model="budget.categoryId"
          :items-type="itemType.CATEGORY"
          :required="true"
          :disabled="budgetLoading"
          label="分类"
          prepend-icon="mdi-shape-outline"
          class="custom-autocomplete input"
        />

        <v-text-field
          v-model="budget.amount"
          :rules="rules.amount"
          :loading="budgetLoading"
          label="预算金额"
          placeholder="5000"
          hint="输入预算上限金额"
          prepend-icon="mdi-cash"
          :suffix="currency || 'CNY'"
          class="input"
          type="number"
          required
        />
      </div>

      <div class="row">
        <v-select
          v-model="budget.period"
          :items="periodOptions"
          :rules="rules.period"
          :loading="budgetLoading"
          label="预算周期"
          prepend-icon="mdi-calendar-clock"
          class="input"
          required
        />

        <v-menu
          v-model="startDateMenu"
          :close-on-content-click="false"
          transition="scale-transition"
          offset-y
          min-width="auto"
        >
          <template v-slot:activator="{ on, attrs }">
            <v-text-field
              :value="formattedStartDate"
              :rules="rules.startDate"
              :loading="budgetLoading"
              label="开始日期"
              prepend-icon="mdi-calendar"
              readonly
              v-bind="attrs"
              v-on="on"
              class="input"
              required
            />
          </template>
          <v-date-picker
            v-model="budget.startDate"
            @input="startDateMenu = false"
            no-title
            scrollable
          />
        </v-menu>
      </div>

      <div class="row">
        <v-menu
          v-model="endDateMenu"
          :close-on-content-click="false"
          transition="scale-transition"
          offset-y
          min-width="auto"
        >
          <template v-slot:activator="{ on, attrs }">
            <v-text-field
              :value="formattedEndDate"
              :loading="budgetLoading"
              label="结束日期（可选）"
              prepend-icon="mdi-calendar"
              readonly
              clearable
              @click:clear="budget.endDate = ''"
              v-bind="attrs"
              v-on="on"
              class="input"
            />
          </template>
          <v-date-picker
            v-model="budget.endDate"
            @input="endDateMenu = false"
            no-title
            scrollable
          />
        </v-menu>

        <div>
          <v-btn
            v-if="update"
            :loading="deleteLoading"
            color="red"
            class="white--text ml-4"
            @click="showDialog = true"
          >
            <v-icon>mdi-delete</v-icon>
          </v-btn>

          <v-btn
            :loading="submitLoading"
            color="primary"
            class="ml-4"
            type="submit"
          >
            <v-icon>mdi-content-save</v-icon>
          </v-btn>
        </div>
      </div>
    </v-form>
  </section>
</template>

<script lang="ts">
import { Component, Prop, Ref, Vue } from "vue-property-decorator";
import { Getter } from "vuex-class";
import BudgetApi, { Budget, CreateBudgetRequest } from "@/api/budgetApi";
import AutocompleteWithIcons from "@/components/inputs/AutocompleteWithIcons.component.vue";
import { ItemsType } from "@/components/inputs/AutocompleteWithIcons.component.vue";
import ConfirmationDialog from "@/components/ConfirmationDialog.component.vue";
import { ErrorHandler } from "@/utils/errorHandler";
import { SUCCESS_MESSAGES } from "@/constants/messages";

interface BudgetForm {
  categoryId: number | null;
  amount: number | null;
  period: "MONTHLY" | "QUARTERLY" | "YEARLY";
  startDate: string;
  endDate: string;
}

@Component({
  components: {
    AutocompleteWitchIcons: AutocompleteWithIcons,
    ConfirmationDialog,
  },
})
export default class CreateUpdateBudget extends Vue {
  @Prop({ type: Boolean, default: false }) update!: boolean;
  @Ref("form") readonly form!: HTMLFormElement;
  @Getter("user/currency") currency: string | undefined;
  @Getter("user/familyId") familyId!: number | null;

  budget: BudgetForm = {
    categoryId: null,
    amount: null,
    period: "MONTHLY",
    startDate: new Date().toISOString().substr(0, 10),
    endDate: "",
  };

  budgetLoading = false;
  submitLoading = false;
  deleteLoading = false;
  showDialog = false;

  startDateMenu = false;
  endDateMenu = false;

  itemType = ItemsType;

  periodOptions = [
    { text: "每月", value: "MONTHLY" },
    { text: "每季度", value: "QUARTERLY" },
    { text: "每年", value: "YEARLY" },
  ];

  rules = {
    amount: [
      (v: number) => !!v || "金额是必填项",
      (v: number) => v > 0 || "金额必须大于0",
    ],
    period: [(v: string) => !!v || "周期是必填项"],
    startDate: [(v: string) => !!v || "开始日期是必填项"],
  };

  get formattedStartDate(): string {
    return this.budget.startDate || "";
  }

  get formattedEndDate(): string {
    return this.budget.endDate || "";
  }

  async mounted(): Promise<void> {
    if (this.update) {
      await this.loadBudget();
    }
  }

  async loadBudget(): Promise<void> {
    const budgetId = this.$route.params.budgetId;
    if (!budgetId) return;

    if (!this.familyId) {
      this.$store.dispatch("snackbar/showSnack", {
        text: "未找到家庭信息，请重新登录",
        color: "error",
      });
      this.$router.push("/budgets");
      return;
    }

    this.budgetLoading = true;
    try {
      const response = await BudgetApi.getById(this.familyId, Number(budgetId));
      const data = response.data;
      this.budget = {
        categoryId: data.categoryId,
        amount: data.amount,
        period: data.period,
        startDate: data.startDate,
        endDate: data.endDate || "",
      };
    } catch (error) {
      console.error("Failed to load budget:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
      this.$router.push("/budgets");
    } finally {
      this.budgetLoading = false;
    }
  }

  async submit(): Promise<void> {
    if (!this.form.validate()) return;

    if (!this.familyId) {
      this.$store.dispatch("snackbar/showSnack", {
        text: "未找到家庭信息，请重新登录",
        color: "error",
      });
      return;
    }

    this.submitLoading = true;
    try {
      const data: CreateBudgetRequest = {
        categoryId: this.budget.categoryId!,
        amount: this.budget.amount!,
        period: this.budget.period,
        startDate: this.budget.startDate,
      };

      if (this.budget.endDate) {
        data.endDate = this.budget.endDate;
      }

      if (this.update) {
        const budgetId = Number(this.$route.params.budgetId);
        await BudgetApi.update(this.familyId, budgetId, data);
        this.$store.dispatch("snackbar/showSnack", {
          text: SUCCESS_MESSAGES.BUDGET_UPDATED,
          color: "success",
        });
      } else {
        await BudgetApi.create(this.familyId, data);
        this.$store.dispatch("snackbar/showSnack", {
          text: SUCCESS_MESSAGES.BUDGET_CREATED,
          color: "success",
        });
      }

      this.$router.push("/budgets");
    } catch (error) {
      console.error("Failed to save budget:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.submitLoading = false;
    }
  }

  async deleteBudget(): Promise<void> {
    const budgetId = Number(this.$route.params.budgetId);
    if (!this.familyId) {
      this.$store.dispatch("snackbar/showSnack", {
        text: "未找到家庭信息，请重新登录",
        color: "error",
      });
      return;
    }
    this.deleteLoading = true;
    try {
      await BudgetApi.delete(this.familyId, budgetId);
      this.$store.dispatch("snackbar/showSnack", {
        text: SUCCESS_MESSAGES.BUDGET_DELETED,
        color: "success",
      });
      this.$router.push("/budgets");
    } catch (error) {
      console.error("Failed to delete budget:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.deleteLoading = false;
      this.showDialog = false;
    }
  }
}
</script>

<style scoped lang="scss">
.main {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.row {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;

  .input {
    flex: 1;
    margin: 0 10px;
    max-width: 500px;
  }

  .custom-autocomplete {
    flex: 1;
    margin: 0 10px;
    max-width: 500px;
  }
}

.max-width {
  max-width: 1100px;
  margin: 0 auto;
  padding: 20px;
}
</style>

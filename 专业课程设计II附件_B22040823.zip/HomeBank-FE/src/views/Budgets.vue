<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <h1 class="text-h4 mb-4">预算管理</h1>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12">
        <v-btn color="primary" @click="$router.push('/budgets/create')">
          <v-icon left>mdi-plus</v-icon>
          创建预算
        </v-btn>
      </v-col>
    </v-row>

    <v-row class="mt-4">
      <v-col cols="12">
        <v-progress-circular
          v-if="loading"
          indeterminate
          color="primary"
        ></v-progress-circular>
        <div v-else>
          <BudgetCard
            v-for="budget in budgets"
            :key="budget.id"
            :budget="budget"
            :budget-status="getBudgetStatus(budget.id)"
            @edit="editBudget"
            @delete="deleteBudget"
          />
          <div v-if="budgets.length === 0" class="text-center text--secondary">
            暂无预算，点击上方按钮创建第一个预算
          </div>
        </div>
      </v-col>
    </v-row>

    <v-dialog v-model="deleteDialog" max-width="400">
      <v-card>
        <v-card-title>确认删除</v-card-title>
        <v-card-text>确定要删除此预算吗？此操作不可撤销。</v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn text @click="deleteDialog = false">取消</v-btn>
          <v-btn color="error" @click="confirmDelete">删除</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Getter } from "vuex-class";
import { Budget, BudgetStatus } from "@/api/budgetApi";
import BudgetApi from "@/api/budgetApi";
import BudgetCard from "@/components/budget/BudgetCard.component.vue";
import { ErrorHandler } from "@/utils/errorHandler";
import { SUCCESS_MESSAGES } from "@/constants/messages";

@Component({
  components: {
    BudgetCard,
  },
})
export default class Budgets extends Vue {
  @Getter("user/familyId") familyId!: number | null;

  budgets: Budget[] = [];
  budgetStatuses: Map<number, BudgetStatus> = new Map();
  loading = false;
  deleteDialog = false;
  budgetToDelete: number | null = null;

  async mounted(): Promise<void> {
    await this.loadBudgets();
  }

  async loadBudgets(): Promise<void> {
    this.loading = true;
    if (!this.familyId) {
      this.$store.dispatch("snackbar/showSnack", {
        text: "未找到家庭信息，请重新登录",
        color: "error",
      });
      this.loading = false;
      return;
    }
    try {
      const response = await BudgetApi.getAll(this.familyId);
      this.budgets = response.data;

      for (const budget of this.budgets) {
        await this.loadBudgetStatus(budget);
      }
    } catch (error) {
      console.error("Failed to load budgets:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.loading = false;
    }
  }

  async loadBudgetStatus(budget: Budget): Promise<void> {
    if (!this.familyId) return;
    try {
      const response = await BudgetApi.getBudgetStatus(
        this.familyId,
        budget.id
      );
      this.budgetStatuses.set(budget.id, response.data);
    } catch (error) {
      console.error(`Failed to load status for budget ${budget.id}:`, error);
    }
  }

  getBudgetStatus(budgetId: number): BudgetStatus | null {
    return this.budgetStatuses.get(budgetId) || null;
  }

  editBudget(budgetId: number): void {
    this.$router.push(`/budgets/${budgetId}`);
  }

  deleteBudget(budgetId: number): void {
    this.budgetToDelete = budgetId;
    this.deleteDialog = true;
  }

  async confirmDelete(): Promise<void> {
    if (!this.familyId || !this.budgetToDelete) return;

    try {
      await BudgetApi.delete(this.familyId, this.budgetToDelete);
      this.budgets = this.budgets.filter((b) => b.id !== this.budgetToDelete);
      this.budgetStatuses.delete(this.budgetToDelete);
      this.$store.dispatch("snackbar/showSnack", {
        text: SUCCESS_MESSAGES.BUDGET_DELETED,
        color: "success",
      });
    } catch (error) {
      console.error("Failed to delete budget:", error);
      this.$store.dispatch("snackbar/showSnack", {
        text: ErrorHandler.getErrorMessage(error),
        color: "error",
      });
    } finally {
      this.deleteDialog = false;
      this.budgetToDelete = null;
    }
  }
}
</script>

<template>
  <section class="max-width main">
    <ConfirmationDialog
      :show.sync="showDialog"
      :label="`确定删除 '${record.label}' 吗？`"
      @confirm="deleteRecord"
    />

    <h1 class="main">
      {{ update ? `编辑 "${record.label}"` : "创建记录" }}
    </h1>

    <v-form class="mt-8" ref="form" @submit.prevent="submit">
      <div class="row">
        <v-text-field
          v-model="record.label"
          :rules="rules.label"
          :counter="40"
          :loading="recordLoading"
          label="标签"
          placeholder="iPhone"
          prepend-icon="mdi-label-outline"
          class="input"
          required
        />

        <v-text-field
          v-model="record.amount"
          :rules="rules.amount"
          :loading="recordLoading"
          label="金额"
          placeholder="1199"
          hint="正数为收入，负数为支出"
          prepend-icon="mdi-cash"
          :suffix="currency"
          class="input"
          type="number"
          required
        />
      </div>

      <div class="row">
        <v-text-field
          v-model="record.note"
          :rules="rules.note"
          :counter="128"
          :loading="recordLoading"
          label="备注"
          placeholder="从商店购买"
          prepend-icon="mdi-note-text-outline"
          class="input"
          required
        />
      </div>

      <div class="row">
        <AutocompleteWitchIcons
          v-model="record.categoryId"
          :items-type="itemType.CATEGORY"
          :required="true"
          label="分类"
          prepend-icon="mdi-shape-outline"
          class="custom-autocomplete"
        />

        <AutocompleteWitchIcons
          v-model="record.accountId"
          :items-type="itemType.ACCOUNT"
          :required="true"
          label="账户"
          prepend-icon="mdi-bank-outline"
          class="custom-autocomplete"
        />
      </div>

      <div class="row">
        <div class="input date-picker-container">
          <DateTimePicker v-model="record.date" :loading="recordLoading" />
        </div>

        <div>
          <v-btn
            v-if="update"
            :loading="deleteLoading"
            color="red"
            class="white--text ml-4"
            @click="showDialog = true"
          >
            <v-icon left>mdi-trash-can-outline</v-icon>
            删除
          </v-btn>

          <v-btn
            color="secondary"
            :loading="submitLoading"
            type="submit"
            class="mx-4"
          >
            <v-icon left>{{ update ? "mdi-update" : "mdi-plus" }}</v-icon>
            {{ update ? "更新" : "创建" }}
          </v-btn>
        </div>
      </div>
    </v-form>
  </section>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import recordApi, { CreateUpdateRecordRequest } from "@/api/recordApi";
import ConfirmationDialog from "@/components/ConfirmationDialog.component.vue";
import { Action, Getter } from "vuex-class";
import errorMessage from "@/services/errorMessage";
import AutocompleteWithIcons from "@/components/inputs/AutocompleteWithIcons.component.vue";
import { ItemsType } from "@/components/inputs/AutocompleteWithIcons.component.vue";
import DateTimePicker from "@/components/inputs/DateTimePicker.component.vue";

@Component({
  components: {
    ConfirmationDialog,
    AutocompleteWitchIcons: AutocompleteWithIcons,
    DateTimePicker,
  },
})
export default class CreateUpdateRecord extends Vue {
  @Prop({ default: false }) update!: boolean;

  itemType = ItemsType;
  recordId = null as null | string;
  submitLoading = false;
  recordLoading = false;
  deleteLoading = false;
  fieldRequiredErrorMsg = "此项为必填项";
  showDialog = false;
  record = {
    id: null,
    amount: 0,
    label: "",
    note: "",
    date: new Date().toISOString(),
    accountId: undefined,
    categoryId: undefined,
    type: undefined,
  } as CreateUpdateRecordRequest;

  rules = {
    label: [
      (value: string): boolean | string =>
        !!value || this.fieldRequiredErrorMsg,
      (value: string): boolean | string =>
        (!!value && value.length <= 40) || "不能超过40个字符",
    ],
    amount: [
      (value: number): boolean | string =>
        !!value || value === 0 || this.fieldRequiredErrorMsg,
    ],
    note: [
      (value: string): boolean | string =>
        value.length <= 128 || "不能超过128个字符",
    ],
  };

  @Getter("user/currency") currency: string | undefined;
  @Getter("user/familyId") familyId!: number | null;

  @Action("snackbar/showSnack") showSnack!: (text: string) => void;

  created(): void {
    this.createdOrActivated();
  }

  activated(): void {
    this.createdOrActivated();
  }

  createdOrActivated(): void {
    if (!this.update) {
      return;
    }
    this.recordId = this.$route.params.recordId;
    this.getRecord();
  }

  submit(): void {
    this.submitLoading = true;

    if (!(this.$refs["form"] as any)?.validate()) {
      this.submitLoading = false;
      return;
    }

    this.record.type = this.record.amount >= 0 ? "INCOME" : "EXPENSE";

    this.record.amount = Math.abs(this.record.amount);
    if (this.update) {
      this.updateRecord();
    } else {
      this.createRecord();
    }
  }

  getRecord(): void {
    this.recordLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.recordLoading = false;
      return;
    }
    if (!this.recordId) {
      this.showSnack("无法加载记录，ID为空");
      this.recordLoading = false;
      return;
    }
    recordApi
      .getById(this.familyId, parseInt(this.recordId))
      .then((response) => {
        this.record = recordApi.recordToCreateUpdateRecordRequest(
          response.data
        );
      })
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.recordLoading = false));
  }

  createRecord(): void {
    this.submitLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.submitLoading = false;
      return;
    }
    recordApi
      .createRecord(this.familyId, this.record)
      .then(() => this.$router.go(-1))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.submitLoading = false));
  }

  updateRecord(): void {
    this.submitLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.submitLoading = false;
      return;
    }
    if (!this.recordId) {
      this.showSnack("无法加载记录，ID为空");
      this.submitLoading = false;
      return;
    }
    recordApi
      .updateRecord(this.familyId, parseInt(this.recordId), this.record)
      .then(() => this.$router.go(-1))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.submitLoading = false));
  }

  deleteRecord(): void {
    this.deleteLoading = true;
    if (!this.familyId) {
      this.showSnack("未找到家庭信息，请重新登录");
      this.deleteLoading = false;
      return;
    }
    if (!this.recordId) {
      this.showSnack("无法加载记录，ID为空");
      this.deleteLoading = false;
      return;
    }
    recordApi
      .deleteRecord(this.familyId, parseInt(this.recordId))
      .then(() => this.$router.push("/dashboard"))
      .catch((error) => this.showSnack(errorMessage.get(error)))
      .finally(() => (this.deleteLoading = false));
  }
}
</script>

<style scoped>
.row {
  display: flex;
  gap: 2rem;
  align-items: center;
  justify-content: space-between;
}

.row .input {
  width: calc(50% - 1rem);
  padding: 0.5rem 1rem;
}

.custom-autocomplete {
  width: calc(50% - 3rem);
  padding: 0.75rem 1rem;
  margin: 0;
}

.date-picker-container {
  display: flex;
  padding-top: 0;
  margin-top: -1rem;
}

@media only screen and (max-width: 750px) {
  .row {
    flex-direction: column;
    align-items: start;
    gap: 0;
  }

  .row .input,
  .custom-autocomplete {
    width: 100%;
  }
}
</style>

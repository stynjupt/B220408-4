import { ErrorHandler } from "@/utils/errorHandler";

const errorMessage = {
  get(error: unknown): string {
    return ErrorHandler.getErrorMessage(error);
  },
};

export default errorMessage;

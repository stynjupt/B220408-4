/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : xiaoyuanershoujiaoyipingtai

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2025-10-24 16:26:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `address` varchar(200) NOT NULL COMMENT '地址',
  `name` varchar(200) DEFAULT NULL COMMENT '收货人',
  `phone` varchar(200) DEFAULT NULL COMMENT '电话',
  `isdefault` varchar(200) DEFAULT NULL COMMENT '是否默认地址',
  `userid` bigint(20) NOT NULL COMMENT '学生id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736141085616 DEFAULT CHARSET=utf8 COMMENT='地址';

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES ('1', '2025-10-24 09:17:26', '地址1', '张三', '19819881111', '是', '11');
INSERT INTO `address` VALUES ('2', '2025-10-24 09:17:26', '地址2', '李四', '19819882222', '是', '12');
INSERT INTO `address` VALUES ('3', '2025-10-24 09:17:26', '地址3', '王五', '19819883333', '是', '13');
INSERT INTO `address` VALUES ('4', '2025-10-24 09:17:26', '地址4', '赵六', '19819884444', '是', '14');
INSERT INTO `address` VALUES ('5', '2025-10-24 09:17:26', '地址5', '孙七', '19819885555', '是', '15');
INSERT INTO `address` VALUES ('6', '2025-10-24 09:17:26', '地址6', '周八', '19819886666', '是', '16');
INSERT INTO `address` VALUES ('1735962886693', '2025-10-24 09:17:26', '地址1', '王先生', '19510153201', '是', '41');
INSERT INTO `address` VALUES ('1736141085615', '2025-10-24 09:17:26', '阿法士大夫', '大不点', '13452632562', '是', '42');

-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `tablename` varchar(200) DEFAULT NULL COMMENT '商品表名',
  `goodid` bigint(20) NOT NULL COMMENT '商品id',
  `goodname` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `picture` longtext NOT NULL COMMENT '图片',
  `buynumber` int(11) DEFAULT NULL COMMENT '购买数量',
  `price` double DEFAULT NULL COMMENT '单价',
  `discountprice` double DEFAULT NULL COMMENT '折扣价',
  `userid` bigint(20) NOT NULL COMMENT '学生id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736141657164 DEFAULT CHARSET=utf8 COMMENT='购物车';

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO `cart` VALUES ('1736141657163', '2025-10-24 09:17:26', 'shangpinxinxi', '61', '小米14', 'file/1736139772559.jpg', '1', '200', null, '42');

-- ----------------------------
-- Table structure for chat
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `adminid` bigint(20) DEFAULT NULL COMMENT '管理员id',
  `ask` longtext DEFAULT NULL COMMENT '提问内容',
  `reply` longtext DEFAULT NULL COMMENT '回复内容',
  `isreply` int(11) DEFAULT NULL COMMENT '是否回复',
  `userid` bigint(20) NOT NULL COMMENT '学生id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736141679525 DEFAULT CHARSET=utf8 COMMENT='客服聊天';

-- ----------------------------
-- Records of chat
-- ----------------------------
INSERT INTO `chat` VALUES ('31', '2025-10-24 09:17:26', '1', '提问内容1', '回复内容1', '1', '1');
INSERT INTO `chat` VALUES ('32', '2025-10-24 09:17:26', '2', '提问内容2', '回复内容2', '2', '2');
INSERT INTO `chat` VALUES ('33', '2025-10-24 09:17:26', '3', '提问内容3', '回复内容3', '3', '3');
INSERT INTO `chat` VALUES ('34', '2025-10-24 09:17:26', '4', '提问内容4', '回复内容4', '4', '4');
INSERT INTO `chat` VALUES ('35', '2025-10-24 09:17:26', '5', '提问内容5', '回复内容5', '5', '5');
INSERT INTO `chat` VALUES ('36', '2025-10-24 09:17:26', '6', '提问内容6', '回复内容6', '6', '6');
INSERT INTO `chat` VALUES ('1736141679524', '2025-10-24 09:17:26', null, '2323', null, '1', '42');

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='配置文件';

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES ('1', 'swiper1', 'file/1736135869641.jpg');
INSERT INTO `config` VALUES ('2', 'swiper2', 'file/1736135377397.jpg');
INSERT INTO `config` VALUES ('3', 'swiper3', 'file/1736135366132.jpg');

-- ----------------------------
-- Table structure for discussshangpinxinxi
-- ----------------------------
DROP TABLE IF EXISTS `discussshangpinxinxi`;
CREATE TABLE `discussshangpinxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `refid` bigint(20) NOT NULL COMMENT '关联表id',
  `userid` bigint(20) NOT NULL COMMENT '学生id',
  `avatarurl` longtext DEFAULT NULL COMMENT '头像',
  `nickname` varchar(200) DEFAULT NULL COMMENT '学生名',
  `content` longtext NOT NULL COMMENT '评论内容',
  `reply` longtext DEFAULT NULL COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品信息评论表';

-- ----------------------------
-- Records of discussshangpinxinxi
-- ----------------------------

-- ----------------------------
-- Table structure for fankuitousu
-- ----------------------------
DROP TABLE IF EXISTS `fankuitousu`;
CREATE TABLE `fankuitousu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `yonghuzhanghao` varchar(200) DEFAULT NULL COMMENT '用户账号',
  `yonghuxingming` varchar(200) DEFAULT NULL COMMENT '用户姓名',
  `fankuibiaoti` varchar(200) NOT NULL COMMENT '投诉标题',
  `fankuineirong` longtext NOT NULL COMMENT '反馈内容',
  `fankuishijian` datetime DEFAULT NULL COMMENT '反馈时间',
  `sfsh` varchar(200) DEFAULT NULL COMMENT '是否审核',
  `shhf` longtext DEFAULT NULL COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736130215828 DEFAULT CHARSET=utf8 COMMENT='投诉';

-- ----------------------------
-- Records of fankuitousu
-- ----------------------------
INSERT INTO `fankuitousu` VALUES ('1736130215827', '2025-10-24 09:17:26', '001', '刘文', '测试以下反馈', '<p>2323</p>', '2025-10-24 09:17:26', '是', '我们会尽快解决');

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `menujson` longtext DEFAULT NULL COMMENT '菜单',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='菜单';

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', '2025-10-24 09:17:26', '[{\r\n	\"backMenu\": [{\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-attentionfavor\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"管理员\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"users\"\r\n		}, {\r\n			\"appFrontIcon\": \"cuIcon-qrcode\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"学生\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"yonghu\"\r\n		}],\r\n		\"fontClass\": \"icon-common1\",\r\n		\"menu\": \"管理员管理\",\r\n		\"unicode\": \"&#xeda3;\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-goodsnew\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"轮播图\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"config\"\r\n		}],\r\n		\"fontClass\": \"icon-common21\",\r\n		\"menu\": \"轮播图管理\",\r\n		\"unicode\": \"&#xee03;\"\r\n	},  {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-goodsnew\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"新闻公告\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"news\"\r\n		}],\r\n		\"fontClass\": \"icon-common21\",\r\n		\"menu\": \"新闻公告管理\",\r\n		\"unicode\": \"&#xee03;\"\r\n	},{\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-wenzi\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"客服聊天\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"chat\"\r\n		}],\r\n		\"fontClass\": \"icon-common1\",\r\n		\"menu\": \"客服聊天管理\",\r\n		\"unicode\": \"&#xeda3;\"\r\n	},  {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-wenzi\",\r\n			\"buttons\": [\"查看\", \"审核\", \"删除\"],\r\n			\"menu\": \"投诉反馈\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"fankuitousu\"\r\n		}],\r\n		\"fontClass\": \"icon-common1\",\r\n		\"menu\": \"投诉反馈管理\",\r\n		\"unicode\": \"&#xeda3;\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-wenzi\",\r\n			\"buttons\": [\"查看\"],\r\n			\"menu\": \"商品求购\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"qiugoushangpin\"\r\n		}],\r\n		\"fontClass\": \"icon-common1\",\r\n		\"menu\": \"商品求购管理\",\r\n		\"unicode\": \"&#xeda3;\"\r\n	},{\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-shop\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"商品类型\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"shangpinleixing\"\r\n		}, {\r\n			\"appFrontIcon\": \"cuIcon-vip\",\r\n			\"buttons\": [\"查看\", \"修改\", \"删除\", \"查看评论\"],\r\n			\"menu\": \"商品信息\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"shangpinxinxi\"\r\n		}],\r\n		\"fontClass\": \"icon-common10\",\r\n		\"menu\": \"商品信息管理\",\r\n		\"unicode\": \"&#xedd1;\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"总价统计\"],\r\n			\"menu\": \"商品订单\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"总价统计\"],\r\n			\"menu\": \"已完成订单\",\r\n			\"menuJump\": \"已完成\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"总价统计\"],\r\n			\"menu\": \"已发货订单\",\r\n			\"menuJump\": \"已发货\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"总价统计\"],\r\n			\"menu\": \"未支付订单\",\r\n			\"menuJump\": \"未支付\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"总价统计\"],\r\n			\"menu\": \"已取消订单\",\r\n			\"menuJump\": \"已取消\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"发货\", \"总价统计\"],\r\n			\"menu\": \"已支付订单\",\r\n			\"menuJump\": \"已支付\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"总价统计\"],\r\n			\"menu\": \"已退款订单\",\r\n			\"menuJump\": \"已退款\",\r\n			\"tableName\": \"orders\"\r\n		}],\r\n	  \r\n		\"menu\": \"订单管理\"\r\n	  	\r\n	}],\r\n	\"frontMenu\": [{\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-circle\",\r\n			\"buttons\": [\"查看\", \"查看评论\"],\r\n			\"menu\": \"商品信息\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"shangpinxinxi\"\r\n		}],\r\n		\"menu\": \"商品信息管理\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-keyboard\",\r\n			\"buttons\": [\"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"购物车\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"cart\"\r\n		}],\r\n		\"menu\": \"购物车管理\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-brand\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"客服聊天\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"chat\"\r\n		}],\r\n		\"menu\": \"客服聊天管理\"\r\n	}],\r\n	\"hasBackLogin\": \"是\",\r\n	\"hasBackRegister\": \"否\",\r\n	\"hasFrontLogin\": \"否\",\r\n	\"hasFrontRegister\": \"否\",\r\n	\"roleName\": \"管理员\",\r\n	\"tableName\": \"users\"\r\n}, {\r\n	\"backMenu\": [{\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-vip\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\", \"查看评论\"],\r\n			\"menu\": \"商品信息\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"shangpinxinxi\"\r\n		}],\r\n		\"fontClass\": \"icon-common10\",\r\n		\"menu\": \"商品信息管理\",\r\n		\"unicode\": \"&#xedd1;\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-vip\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"商品求购\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"qiugoushangpin\"\r\n		}],\r\n		\"fontClass\": \"icon-common10\",\r\n		\"menu\": \"商品求购管理\",\r\n		\"unicode\": \"&#xedd1;\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\"],\r\n			\"menu\": \"已取消订单\",\r\n			\"menuJump\": \"已取消\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\"],\r\n			\"menu\": \"已支付订单\",\r\n			\"menuJump\": \"已支付\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\"],\r\n			\"menu\": \"已退款订单\",\r\n			\"menuJump\": \"已退款\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\"],\r\n			\"menu\": \"商品订单\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\"],\r\n			\"menu\": \"已完成订单\",\r\n			\"menuJump\": \"已完成\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\", \"确认收货\"],\r\n			\"menu\": \"已发货订单\",\r\n			\"menuJump\": \"已发货\",\r\n			\"tableName\": \"orders\"\r\n		}, {\r\n			\"appFrontIcon\": \"icon-common10\",\r\n			\"buttons\": [\"查看\"],\r\n			\"menu\": \"未支付订单\",\r\n			\"menuJump\": \"未支付\",\r\n			\"tableName\": \"orders\"\r\n		}],\r\n		\"menu\": \"订单管理\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-similar\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"地址\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"address\"\r\n		}],\r\n		\"fontClass\": \"icon-common49\",\r\n		\"menu\": \"地址管理\",\r\n		\"unicode\": \"&#xef79;\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-keyboard\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"我的收藏\",\r\n			\"menuJump\": \"1\",\r\n			\"tableName\": \"storeup\"\r\n		}],\r\n		\"fontClass\": \"icon-common22\",\r\n		\"menu\": \"我的收藏管理\",\r\n		\"unicode\": \"&#xee04;\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-keyboard\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"投诉\",\r\n			\"menuJump\": \"1\",\r\n			\"tableName\": \"fankuitousu\"\r\n		}],\r\n		\"fontClass\": \"icon-common22\",\r\n		\"menu\": \"投诉反馈管理\",\r\n		\"unicode\": \"&#xee04;\"\r\n	}],\r\n	\"frontMenu\": [{\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-circle\",\r\n			\"buttons\": [\"查看\", \"查看评论\"],\r\n			\"menu\": \"商品信息\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"shangpinxinxi\"\r\n		}],\r\n		\"menu\": \"商品信息管理\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-circle\",\r\n			\"buttons\": [\"查看\", \"查看评论\"],\r\n			\"menu\": \"商品求购\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"qiugoushangpin\"\r\n		}],\r\n		\"menu\": \"商品求购管理\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-keyboard\",\r\n			\"buttons\": [\"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"购物车\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"cart\"\r\n		}],\r\n		\"menu\": \"购物车管理\"\r\n	}, {\r\n		\"child\": [{\r\n			\"appFrontIcon\": \"cuIcon-brand\",\r\n			\"buttons\": [\"新增\", \"查看\", \"修改\", \"删除\"],\r\n			\"menu\": \"客服聊天\",\r\n			\"menuJump\": \"列表\",\r\n			\"tableName\": \"chat\"\r\n		}],\r\n		\"menu\": \"客服聊天管理\"\r\n	}],\r\n	\"hasBackLogin\": \"否\",\r\n	\"hasBackRegister\": \"否\",\r\n	\"hasFrontLogin\": \"是\",\r\n	\"hasFrontRegister\": \"是\",\r\n	\"roleName\": \"学生\",\r\n	\"tableName\": \"yonghu\"\r\n}]');

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `introduction` longtext DEFAULT NULL COMMENT '简介',
  `picture` longtext NOT NULL COMMENT '图片',
  `content` longtext NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1732853121050 DEFAULT CHARSET=utf8 COMMENT='公告资讯';

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1732853052947', '2025-10-24 09:17:26', '这是一个商品资讯', '大家都快来买东西呀', 'file/1736144908555.jpg', '<p>大家都快来买东西呀大家都快来买东西呀大家都快来买东西呀大家都快来买东西呀大家都快来买东西呀</p>');
INSERT INTO `news` VALUES ('1732853121049', '2025-10-24 09:17:26', '今天有活动', '今天有活动', 'file/1736144894431.jpg', '<p>今天有活动今天有活动今天有活动</p>');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `orderid` varchar(200) NOT NULL COMMENT '订单编号',
  `tablename` varchar(200) DEFAULT NULL COMMENT '商品表名',
  `goodid` bigint(20) NOT NULL COMMENT '商品id',
  `goodname` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `picture` longtext NOT NULL COMMENT '图片',
  `buynumber` int(11) DEFAULT NULL COMMENT '购买数量',
  `price` double DEFAULT NULL COMMENT '单价',
  `discountprice` double DEFAULT NULL COMMENT '折扣价',
  `total` double DEFAULT NULL COMMENT '总价',
  `discounttotal` double DEFAULT NULL COMMENT '折扣总价格',
  `type` varchar(200) DEFAULT NULL COMMENT '支付类型',
  `status` varchar(200) DEFAULT NULL COMMENT '订单状态',
  `address` varchar(200) DEFAULT NULL COMMENT '地址',
  `tel` varchar(200) DEFAULT NULL COMMENT '电话',
  `consignee` varchar(200) DEFAULT NULL COMMENT '收货人',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  `logistics` longtext DEFAULT NULL COMMENT '物流',
  `userid` bigint(20) NOT NULL COMMENT '学生id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=1736145161273 DEFAULT CHARSET=utf8 COMMENT='商品订单';

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('1736141668916', '2025-10-24 09:17:26', '2025161334287', 'shangpinxinxi', '62', '小金链子', 'file/1736139626868.jpg', '1', '1300', '1300', '1300', '1300', '1', '未支付', '阿法士大夫', '13452632562', '大不点', '', null, '42');
INSERT INTO `orders` VALUES ('1736141704310', '2025-10-24 09:17:26', '20251613353868', 'shangpinxinxi', '62', '小金链子', 'file/1736139626868.jpg', '1', '1300', '1300', '1300', '1300', '1', '已支付', '阿法士大夫', '13452632562', '大不点', '', null, '42');
INSERT INTO `orders` VALUES ('1736145161272', '2025-10-24 09:17:26', '202516143240938', 'shangpinxinxi', '1735962716052', '联想笔记本', 'file/1736135466926.jpg', '1', '4500', '4500', '4500', '4500', '1', '已支付', '阿法士大夫', '13452632562', '大不点', '', null, '42');

-- ----------------------------
-- Table structure for qiugoushangpin
-- ----------------------------
DROP TABLE IF EXISTS `qiugoushangpin`;
CREATE TABLE `qiugoushangpin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `shangpinmingcheng` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `shangpinleixing` varchar(200) DEFAULT NULL COMMENT '商品类型',
  `shangpintupian` longtext DEFAULT NULL COMMENT '商品图片',
  `shangpinjianjie` longtext DEFAULT NULL COMMENT '商品简介',
  `shangpinxiangqing` longtext DEFAULT NULL COMMENT '求购详情',
  `yonghuzhanghao` varchar(200) DEFAULT NULL COMMENT '学生账号',
  `yonghuxingming` varchar(200) DEFAULT NULL COMMENT '学生姓名',
  `price` double DEFAULT NULL COMMENT '预算价格',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736140999206 DEFAULT CHARSET=utf8 COMMENT='求购商品';

-- ----------------------------
-- Records of qiugoushangpin
-- ----------------------------
INSERT INTO `qiugoushangpin` VALUES ('1736134303129', '2025-10-24 09:17:26', '求购二手办公桌', '‌家居用品', 'file/1736140132511.jpg', '阿杜是发送到', '<p>阿道夫稍等</p>', '001', '刘文', '12');
INSERT INTO `qiugoushangpin` VALUES ('1736140999205', '2025-10-24 09:17:26', '求购二手苹果手机', '‌电子产品', 'file/1736140988679.jpeg', '求购二手苹果手机', '<p>求购二手苹果手机</p>', '002', '赵浩天', '2000');

-- ----------------------------
-- Table structure for shangpinleixing
-- ----------------------------
DROP TABLE IF EXISTS `shangpinleixing`;
CREATE TABLE `shangpinleixing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `shangpinleixing` varchar(200) DEFAULT NULL COMMENT '商品类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736131019101 DEFAULT CHARSET=utf8 COMMENT='商品类型';

-- ----------------------------
-- Records of shangpinleixing
-- ----------------------------
INSERT INTO `shangpinleixing` VALUES ('53', '2025-10-24 09:17:26', '‌二手教科书');
INSERT INTO `shangpinleixing` VALUES ('54', '2025-10-24 09:17:26', '‌电子产品');
INSERT INTO `shangpinleixing` VALUES ('55', '2025-10-24 09:17:26', '‌家居用品');
INSERT INTO `shangpinleixing` VALUES ('56', '2025-10-24 09:17:26', '‌体育用品');
INSERT INTO `shangpinleixing` VALUES ('1735962599757', '2025-10-24 09:17:26', '‌文具用品');
INSERT INTO `shangpinleixing` VALUES ('1736130991410', '2025-10-24 09:17:26', '‌生活用品');
INSERT INTO `shangpinleixing` VALUES ('1736131002130', '2025-10-24 09:17:26', '‌时尚饰品');
INSERT INTO `shangpinleixing` VALUES ('1736131011812', '2025-10-24 09:17:26', '‌自行车');
INSERT INTO `shangpinleixing` VALUES ('1736131019100', '2025-10-24 09:17:26', '其他');

-- ----------------------------
-- Table structure for shangpinxinxi
-- ----------------------------
DROP TABLE IF EXISTS `shangpinxinxi`;
CREATE TABLE `shangpinxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `shangpinmingcheng` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `shangpinleixing` varchar(200) DEFAULT NULL COMMENT '商品类型',
  `shangpintupian` longtext DEFAULT NULL COMMENT '商品图片',
  `shangpinjianjie` longtext DEFAULT NULL COMMENT '商品简介',
  `shangpinxiangqing` longtext DEFAULT NULL COMMENT '商品详情',
  `yonghuzhanghao` varchar(200) DEFAULT NULL COMMENT '学生账号',
  `yonghuxingming` varchar(200) DEFAULT NULL COMMENT '学生姓名',
  `price` double DEFAULT NULL COMMENT '价格',
  `storeupnum` int(11) DEFAULT NULL COMMENT '收藏数量',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736133560648 DEFAULT CHARSET=utf8 COMMENT='商品信息';

-- ----------------------------
-- Records of shangpinxinxi
-- ----------------------------
INSERT INTO `shangpinxinxi` VALUES ('61', '2025-10-24 09:17:26', '小米14', '‌二手教科书', 'file/1736139772559.jpg', '高等数学', '<p>高等数学</p>', '001', '刘文', '200', '2', '2025-10-24 09:17:26');
INSERT INTO `shangpinxinxi` VALUES ('62', '2025-10-24 09:17:26', '小金链子', '‌时尚饰品', 'file/1736139626868.jpg', '小金链子', '<p>小金链子小金链子</p>', '002', '赵浩天', '1300', '3', '2025-10-24 09:17:26');
INSERT INTO `shangpinxinxi` VALUES ('63', '2025-10-24 09:17:26', '小米civi4', '‌电子产品', 'file/1736138939419.jpeg', '商品简介3', '<p>商品详情3</p>', '003', '李佳琪', '3500', '4', '2025-10-24 09:17:26');
INSERT INTO `shangpinxinxi` VALUES ('64', '2025-10-24 09:17:26', '篮球', '‌体育用品', 'file/1736139553430.jpg', '非常好用的篮球', '<p>非常好用的篮球</p>', '004', '刘静', '2300', '4', '2025-10-24 09:17:26');
INSERT INTO `shangpinxinxi` VALUES ('65', '2025-10-24 09:17:26', '马克笔', '‌文具用品', 'file/1736139497401.jpeg', '马克笔', '<p>马克笔</p>', '005', '张志强', '1800', '5', '2025-10-24 09:17:26');
INSERT INTO `shangpinxinxi` VALUES ('66', '2025-10-24 09:17:26', '山地自行车', '‌自行车', 'file/1736139376524.jpeg', '非常新的一个自行车', '<p>非常新的一个自行车非常新的一个自行车非常新的一个自行车</p>', '006', '王浩', '7000', '6', '2025-10-24 09:17:26');
INSERT INTO `shangpinxinxi` VALUES ('1735962716052', '2025-10-24 09:17:26', '联想笔记本', '‌电子产品', 'file/1736135466926.jpg', '联想笔记本', '<p>非常好用的</p>', '001', '刘文', '4500', '1', '2025-10-24 09:17:26');

-- ----------------------------
-- Table structure for storeup
-- ----------------------------
DROP TABLE IF EXISTS `storeup`;
CREATE TABLE `storeup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `refid` bigint(20) DEFAULT NULL COMMENT 'refid',
  `tablename` varchar(200) DEFAULT NULL COMMENT '表名',
  `name` varchar(200) NOT NULL COMMENT '名称',
  `picture` longtext NOT NULL COMMENT '图片',
  `type` varchar(200) DEFAULT NULL COMMENT '类型(1:收藏,21:赞,22:踩,31:竞拍参与,41:关注)',
  `inteltype` varchar(200) DEFAULT NULL COMMENT '推荐类型',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  `userid` bigint(20) NOT NULL COMMENT '学生id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1736145154400 DEFAULT CHARSET=utf8 COMMENT='我的收藏';

-- ----------------------------
-- Records of storeup
-- ----------------------------
INSERT INTO `storeup` VALUES ('1736145154399', '2025-10-24 09:17:26', '1735962716052', 'shangpinxinxi', '联想笔记本', 'file/1736135466926.jpg', '1', null, null, '42');

-- ----------------------------
-- Table structure for token
-- ----------------------------
DROP TABLE IF EXISTS `token`;
CREATE TABLE `token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '学生id',
  `username` varchar(100) NOT NULL COMMENT '学生名',
  `tablename` varchar(100) DEFAULT NULL COMMENT '表名',
  `role` varchar(100) DEFAULT NULL COMMENT '角色',
  `token` varchar(200) NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '过期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='token表';

-- ----------------------------
-- Records of token
-- ----------------------------
INSERT INTO `token` VALUES ('3', '41', '001', 'yonghu', '学生', 'd1jushzl5wwmx88rnildwt2cfn15s55f', '2025-10-24 09:17:26', '2025-10-24 17:23:51');
INSERT INTO `token` VALUES ('4', '1', 'admin', 'users', '管理员', 'kujxf4ktvklxak8wf6i21h41p0iid7cq', '2025-10-24 09:17:26', '2025-10-24 17:22:28');
INSERT INTO `token` VALUES ('5', '41', '001', 'yonghu', '用户', 'eyl0l8tp32rws63k1n35vuvf74804ldb', '2025-10-24 09:17:26', '2025-10-24 09:17:26');
INSERT INTO `token` VALUES ('6', '42', '002', 'yonghu', '学生', 'h2b4uh3lynh1ox1l83ufdgfo8rbkb6ej', '2025-10-24 09:17:26', '2025-10-24 09:17:26');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `username` varchar(200) NOT NULL COMMENT '学生名',
  `password` varchar(200) NOT NULL COMMENT '密码',
  `role` varchar(200) DEFAULT NULL COMMENT '角色',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员';

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', '2025-10-24 09:17:26', 'admin', 'admin', '管理员');

-- ----------------------------
-- Table structure for yonghu
-- ----------------------------
DROP TABLE IF EXISTS `yonghu`;
CREATE TABLE `yonghu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '创建时间',
  `yonghuzhanghao` varchar(200) NOT NULL COMMENT '学生账号',
  `yonghumima` varchar(200) NOT NULL COMMENT '学生密码',
  `yonghuxingming` varchar(200) NOT NULL COMMENT '学生姓名',
  `touxiang` longtext DEFAULT NULL COMMENT '头像',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `shoujihaoma` varchar(200) DEFAULT NULL COMMENT '手机号码',
  `money` double DEFAULT 0 COMMENT '余额',
  PRIMARY KEY (`id`),
  UNIQUE KEY `yonghuzhanghao` (`yonghuzhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='学生';

-- ----------------------------
-- Records of yonghu
-- ----------------------------
INSERT INTO `yonghu` VALUES ('41', '2025-10-24 09:17:26', '001', 'e10adc3949ba59abbe56e057f20f883e', '刘文', 'file/1736140840436.jpg', '男', '19819881111', '86100');
INSERT INTO `yonghu` VALUES ('42', '2025-10-24 09:17:26', '002', 'e10adc3949ba59abbe56e057f20f883e', '赵浩天', 'file/1736140823658.jpg', '男', '19819881112', '14400');
INSERT INTO `yonghu` VALUES ('43', '2025-10-24 09:17:26', '003', 'e10adc3949ba59abbe56e057f20f883e', '李佳琪', 'file/1736140809938.jpg', '女', '19819881113', '200');
INSERT INTO `yonghu` VALUES ('44', '2025-10-24 09:17:26', '004', 'e10adc3949ba59abbe56e057f20f883e', '刘静', 'file/1736140755394.jpg', '女', '19819881114', '200');
INSERT INTO `yonghu` VALUES ('45', '2025-10-24 09:17:26', '005', 'e10adc3949ba59abbe56e057f20f883e', '张志强', 'file/1736140739034.jpg', '男', '19819881115', '200');
INSERT INTO `yonghu` VALUES ('46', '2025-10-24 09:17:26', '006', 'e10adc3949ba59abbe56e057f20f883e', '王浩', 'file/1736140703506.jpeg', '男', '19819881116', '200');

package com.cl.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import com.cl.entity.QiugoushangpinEntity;
import com.cl.entity.view.QiugoushangpinView;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * 求购商品信息
 * 
 * @author 
 * @email 
 * @date
 */
public interface QiugoushangpinDao extends BaseMapper<QiugoushangpinEntity> {
	
	List<QiugoushangpinView> selectListView(@Param("ew") Wrapper<QiugoushangpinEntity> wrapper);

	List<QiugoushangpinView> selectListView(Pagination page, @Param("ew") Wrapper<QiugoushangpinEntity> wrapper);
	
	QiugoushangpinView selectView(@Param("ew") Wrapper<QiugoushangpinEntity> wrapper);
	

}

package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.entity.QiugoushangpinEntity;
import com.cl.entity.view.QiugoushangpinView;
import com.cl.utils.PageUtils;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


/**
 * 求购商品信息
 *
 * @author 
 * @email 
 * @date
 */
public interface QiugoushangpinService extends IService<QiugoushangpinEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<QiugoushangpinView> selectListView(Wrapper<QiugoushangpinEntity> wrapper);
   	
   	QiugoushangpinView selectView(@Param("ew") Wrapper<QiugoushangpinEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params, Wrapper<QiugoushangpinEntity> wrapper);
   	

}


package com.cl.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.dao.QiugoushangpinDao;
import com.cl.entity.QiugoushangpinEntity;
import com.cl.entity.view.QiugoushangpinView;
import com.cl.service.QiugoushangpinService;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("qiugoushangpinService")
public class QiugoushangpinServiceImpl extends ServiceImpl<QiugoushangpinDao, QiugoushangpinEntity> implements QiugoushangpinService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<QiugoushangpinEntity> page = this.selectPage(
                new Query<QiugoushangpinEntity>(params).getPage(),
                new EntityWrapper<QiugoushangpinEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<QiugoushangpinEntity> wrapper) {
		  Page<QiugoushangpinView> page =new Query<QiugoushangpinView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<QiugoushangpinView> selectListView(Wrapper<QiugoushangpinEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public QiugoushangpinView selectView(Wrapper<QiugoushangpinEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}

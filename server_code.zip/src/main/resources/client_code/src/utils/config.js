const config = {
    get() {
        return {
            url : process.env.VUE_APP_BASE_API_URL + process.env.VUE_APP_BASE_API + '/',
            name: process.env.VUE_APP_BASE_API,
			menuList:[
				{
					name: '商品信息管理',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'商品信息',
							url:'/index/shangpinxinxiList'
						},
					]
				},
				{
					name: '商品求购管理',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'商品求购',
							url:'/index/qiugoushangpinList'
						},
					]
				},
				{
					name: '购物车管理',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'购物车',
							url:'/index/cartList'
						},
					]
				},
				{
					name: '新闻公告管理',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'新闻公告',
							url:'/index/newsList'
						},
					]
				},
				{
					name: '客服聊天管理',
					icon: '${frontMenu.fontClass}',
					child:[
						{
							name:'客服聊天',
							url:'chat'
						},
					]
				},
			]
        }
    },
    getProjectName(){
        return {
            projectName: "校园二手交易平台"
        } 
    }
}
export default config
